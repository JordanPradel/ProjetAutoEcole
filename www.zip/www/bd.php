<?php
	/*
	 * Cette fonction renvoie l'id de l'utilisateur s'il existe en base de données
	 */
	function setIdUtilisateur($lemail, $lepassword){
		
		$retIdUtilisateur = "";
	
		/* Connexion à MySQL */
		$cnx = mysql_connect("localhost","root","");
		/* Erreur si connexion échouée */
		if(!$cnx){
			echo 'Impossible de se connecter : ' . mysql_error();
		}
		/* Choix de la BD */
		mysql_select_db("site-photos");
	
		/* Requete pour récupérer les mails et les passwords */
		$requete1 = "SELECT idUtilisateur, mail, password FROM utilisateur";
		$resultat1 = mysql_query($requete1);
		
		/* Curseur pour rechercher le mail et le mot de passe passés en paramètre */
		while($ligne_courante=mysql_fetch_object($resultat1)) {	
			
			/* Si le mail et le mot de passe sont trouvés, on renvoie l'id utilisateur */
			if ($ligne_courante->mail == $lemail && $ligne_courante->password == $lepassword) {
				$retIdUtilisateur = $ligne_courante->idUtilisateur;
			}				
		}
		mysql_close(); // Déconnexion de MySQL
		if($retIdUtilisateur) {
			echo '<script>alert("Connexion réussie")</script>';
			$_SESSION['utilConnecte'] = $retIdUtilisateur;
			initialisationSession();
			echo "<script type='text/javascript'>document.location.replace('index.php');</script>";
		}
		else {
			echo '<script>alert("Problème lors de la saisie")</script>';
		}

	}
?>