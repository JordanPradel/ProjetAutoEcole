<?php
include_once($site_racine . 'bdd/utilisateur_bdd.php');
$utilisateur_bdd = new Utilisateur_bdd();
$utilisateur = $utilisateur_bdd->getNomPrenom();

//echo '<pre>';var_dump($_SESSION);echo '</pre>';
?>

<!-- Navigation -->
<nav class="navbar navbar-default navbar-static-top" role="navigation" style="margin-bottom: 0">

	<div class="navbar-header">
		<button type="button" class="navbar-toggle" data-toggle="collapse" data-target=".navbar-collapse">
		</button>
		<div class="navbar-brand">
			<a class="navbar-logo" href="<?php echo $site_url . $repertoire_pages; ?>index.php">
				<img src="<?php echo $site_url ?>structure/images/3Il.png"
					 title="3Syl-spp" alt="3SylAuto-spp"/>
			</a>
		</div>
		<div class="navbar-brand">Bonjour <?php
			echo $utilisateur; ?></div>
	</div>
	<!-- /.navbar-header -->

	<ul class="nav navbar-top-links navbar-right">

		<!-- /.dropdown -->
		<li class="dropdown">
			<a href="<?php echo $site_url . $repertoire_pages; ?>session/mon_compte.php">
				<i class="fa fa-user fa-fw"></i> <i><?php echo $utilisateur ?></i>
			</a>
			<!-- /.dropdown-user -->
		</li>
		<!-- /.dropdown -->
		<!-- /.dropdown -->
		<li class="dropdown">
			<a href="<?php echo $site_url . $repertoire_pages; ?>session/deconnexion.php">
				<i class="glyphicon glyphicon-log-out "></i> <i>Se déconnecter </i>
			</a>
			<!-- /.dropdown-user -->
		</li>
		<!-- /.dropdown -->
	</ul>
	<!-- /.navbar-top-links -->


	<?php
	$toto['profil'] = 'secretaire';
	//var_dump($_SESSION);
	//die("die");
	switch ($toto['profil']) {
//	switch ($_SESSION['profil']) {
		case 'secretaire';
			include($site_racine .'structure/navigation/secretaire_navigation.php');

			break;
		case 'moniteur';
			include($site_racine .'structure/navigation/moniteur_navigation.php');
			return;
			break;
		case 'eleve':
			include($site_racine .'structure/eleve_navigation.php');

		default:
			break;

	}
	?>
</nav>