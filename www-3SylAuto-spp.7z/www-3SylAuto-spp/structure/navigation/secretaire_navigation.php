<div class="navbar-default sidebar" role="navigation">
    <div class="sidebar-nav navbar-collapse">
        <ul class="nav" id="side-menu">
            <li class="sidebar-search">
                <div class="input-group custom-search-form">
                    <input type="text" class="form-control" placeholder="Search...">
						<span class="input-group-btn">
							<button class="btn btn-default" type="button">
                                <i class="fa fa-search"></i>
                            </button>
						</span>
                </div>
                <!-- /input-group -->
            </li>
            <!-- EMPLOYES -->
            <li>
                <a href="#"><i class="fa fa-bar-chart-o fa-fw"></i> Employés<span class="fa arrow"></span></a>
                <ul class="nav nav-second-level">
                    <li>
                        <a href="<?php echo $site_url.$repertoire_pages; ?>moniteurs/gestion.php">Moniteurs</a>
                    </li>
                </ul>
            </li>
            <!-- VEHICULES -->
            <li>
                <a href="#"><i class="fa fa-bar-chart-o fa-fw"></i> Véhicules<span class="fa arrow"></span></a>
                <ul class="nav nav-second-level">
                    <li>
                        <a href="<?php echo $site_url.$repertoire_pages; ?>voitures/gestion.php">Voitures</a>
                    </li>
                </ul>
            </li>
            <!-- CLIENTS -->
            <li>
                <a href="#"><i class="fa fa-bar-chart-o fa-fw"></i> Clients<span class="fa arrow"></span></a>
                <ul class="nav nav-second-level">
                    <li>
                        <a href="<?php echo $site_url.$repertoire_pages; ?>clients/gestion.php">Tous les clients</a>
                    </li>
                </ul>
                <ul class="nav nav-second-level">
                    <li>
                        <a href="<?php echo $site_url.$repertoire_pages; ?>eleves/gestion.php">Tous les élèves</a>
                    </li>
                </ul>
                <ul class="nav nav-second-level">
                    <li>
                        <a href="<?php echo $site_url.$repertoire_pages; ?>factures/gestion.php">Toutes les factures</a>
                    </li>
                </ul>
            </li>
            <!-- LECONS -->
            <li>
                <a href="#"><i class="fa fa-bar-chart-o fa-fw"></i> Agendas<span class="fa arrow"></span></a>
                <ul class="nav nav-second-level">
                    <li>
                        <a href="<?php echo $site_url.$repertoire_pages; ?>agendas/agenda_eleve.php">Agenda eleve</a>
                    </li>
                </ul>
                <ul class="nav nav-second-level">
                    <li>
                        <a href="<?php echo $site_url.$repertoire_pages; ?>agendas/agenda_moniteur.php">Agenda moniteur</a>
                    </li>
                </ul>
            </li>
            <!-- EXAMENS -->
            <li>
                <a href="#"><i class="fa fa-bar-chart-o fa-fw"></i> Examens<span class="fa arrow"></span></a>
                <ul class="nav nav-second-level">
                    <li>
                        <a href="<?php echo $site_url.$repertoire_pages; ?>examens/gestion.php">Agenda examens</a>
                    </li>
                </ul>
            </li>
        </ul>
    </div>
    <!-- /.sidebar-collapse -->
</div>
<!-- /.navbar-static-side -->