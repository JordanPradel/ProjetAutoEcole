<?php
	include_once($site_racine.'bdd/utilisateur_bdd.php');
	$utilisateur_bdd = new Utilisateur_bdd();
	$utilisateur = $utilisateur_bdd->getNomPrenom();
?>

<!-- Navigation -->
<nav class="navbar navbar-default navbar-static-top" role="navigation" style="margin-bottom: 0">

<div class="navbar-header">
    <button type="button" class="navbar-toggle" data-toggle="collapse" data-target=".navbar-collapse">
    </button>
	<div class="navbar-brand">
    <a class="navbar-logo" href="<?php echo $site_url . $repertoire_pages; ?>index.php"><img src="/images/3Il.png" title="Septime | Data Room" alt="Septime | Data Room" /></a>
    </div>
	<div class="navbar-brand">Bonjour <?php
		echo $utilisateur; ?></div>
</div>
<!-- /.navbar-header -->


<ul class="nav navbar-top-links navbar-right">

    <!-- /.dropdown -->
    <li class="dropdown">
        <a href="<?php echo $site_url . $repertoire_pages; ?>session/mon_compte.php">
            <i class="fa fa-user fa-fw"></i> <i><?php echo $utilisateur ?></i>
        </a>
        <!-- /.dropdown-user -->
    </li>
    <!-- /.dropdown -->
    <!-- /.dropdown -->
    <li class="dropdown">
        <a href="<?php echo $site_url . $repertoire_pages; ?>session/deconnexion.php">
            <i class="glyphicon glyphicon-log-out "></i> <i>Se déconnecter </i>
        </a>
        <!-- /.dropdown-user -->
    </li>
    <!-- /.dropdown -->
</ul>
<!-- /.navbar-top-links -->

	<div class="navbar-default sidebar" role="navigation">
		<div class="sidebar-nav navbar-collapse">
			<ul class="nav" id="side-menu">

				<?php
					// NAVIGATION SECRETAIRE
					if (isset($_SESSION["profil"]) && $_SESSION["profil"] == "secretaire") {
				?>
				<!-- EMPLOYES -->
				<li>
					<a href="#"><i class="fa fa-bar-chart-o fa-fw"></i> Employés<span class="fa arrow"></span></a>
					<ul class="nav nav-second-level">
						<li>
							<a href="<?php echo $site_url.$repertoire_pages; ?>secretaire/moniteur/gestion.php">Moniteurs</a>
						</li>
					</ul>
				</li>
				<!-- VEHICULES -->
				<li>
					<a href="#"><i class="fa fa-bar-chart-o fa-fw"></i> Véhicules<span class="fa arrow"></span></a>
					<ul class="nav nav-second-level">
						<li>
							<a href="voitures.php">Voitures</a>
						</li>
					</ul>
				</li>
				<!-- CLIENTS -->
				<li>
					<a href="#"><i class="fa fa-bar-chart-o fa-fw"></i> Clients<span class="fa arrow"></span></a>
					<ul class="nav nav-second-level">
						<li>
							<a href="<?php echo $site_url.$repertoire_pages; ?>secretaire/client/gestion.php">Tous les clients</a>
						</li>
					</ul>
					<ul class="nav nav-second-level">
						<li>
							<a href="<?php echo $site_url.$repertoire_pages; ?>secretaire/eleve/gestion.php">Tous les élèves</a>
						</li>
					</ul>
					<ul class="nav nav-second-level">
						<li>
							<a href="factures.php">Toutes les factures</a>
						</li>
					</ul>
				</li>
				<!-- LECONS -->
				<li>
					<a href="#"><i class="fa fa-bar-chart-o fa-fw"></i> Leçons<span class="fa arrow"></span></a>
					<ul class="nav nav-second-level">
						<li>
							<a href="<?php echo $site_url.$repertoire_pages; ?>secretaire\lecon\eleve\gestion.php">Agenda eleve</a>
						</li>
					</ul>
					<ul class="nav nav-second-level">
						<li>
							<a href="<?php echo $site_url.$repertoire_pages; ?>secretaire\lecon\moniteur\gestion.php">Agenda moniteur</a>
						</li>
					</ul>
				</li>
				<!-- EXAMENS -->
				<li>
					<a href="#"><i class="fa fa-bar-chart-o fa-fw"></i> Examens<span class="fa arrow"></span></a>
					<ul class="nav nav-second-level">
						<li>
							<a href="moniteurs.php">Agenda examens</a>
						</li>
					</ul>
				</li>
				<?php
					// NAVIGATION MONITEUR
					} else if (isset($_SESSION["profil"]) && $_SESSION["profil"] == "moniteur") {
				?>
				<!-- AGENDAS -->
				<li>
					<a href="#"><i class="fa fa-bar-chart-o fa-fw"></i> Agendas<span class="fa arrow"></span></a>
					<ul class="nav nav-second-level">
						<li>
							<a href="lecons_conduite_eleveMoniteur.php">Agenda global</a>
						</li>
					</ul>
				</li>
				<!-- INFOS COMPTE -->
				<li>
					<a href="#"><i class="fa fa-bar-chart-o fa-fw"></i> Informations du compte<span class="fa arrow"></span></a>
					<ul class="nav nav-second-level">
						<li>
							<a href="<?php echo $site_racine . $repertoire_pages; ?>moniteurs/consulter.php">Profil</a>
						</li>
					</ul>
				</li>
				<?php
					// NAVIGATION ELEVE
					} else if (isset($_SESSION["profil"]) && $_SESSION["profil"] == "eleve") {
				?>
				<!-- AGENDAS -->
				<li>
					<a href="#"><i class="fa fa-bar-chart-o fa-fw"></i> Agendas<span class="fa arrow"></span></a>
					<ul class="nav nav-second-level">
						<li>
							<a href="<?php echo $site_url.$repertoire_pages; ?>lecons_conduite_eleveMoniteur.php">Agenda global</a>
						</li>
					</ul>
					<ul class="nav nav-second-level">
						<li>
							<a href="<?php echo $site_url.$repertoire_pages; ?>lecons_code.php">Agenda du code</a>
						</li>
					</ul>
				</li>
				<!-- INFOS COMPTE -->
				<li>
					<a href="#"><i class="fa fa-bar-chart-o fa-fw"></i> Informations du compte<span class="fa arrow"></span></a>
					<ul class="nav nav-second-level">
						<li>
							<a href="<?php echo $site_url.$repertoire_pages; ?>eleves/consulter.php">Profil</a>
						</li>
					</ul>
					<ul class="nav nav-second-level">
						<li>
							<a href="lecons_code.php">Factures</a>
						</li>
					</ul>
				</li>
				<?php
					}
				?>
			</ul>
		</div>
		<!-- /.sidebar-collapse -->
	</div>
	<!-- /.navbar-static-side -->
</nav>