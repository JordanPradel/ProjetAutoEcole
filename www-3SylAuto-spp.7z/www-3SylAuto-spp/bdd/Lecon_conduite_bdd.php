<?php
include_once 'bdd.php';
/**
 * Auteur: Colin PEREMARTY
 */
class Lecon_conduite_bdd extends Model
{
    public $model_name = 'lecon_conduite';

    public $id_name = 'leconNum';

    protected $champs = array(
        'leconNum'     => null,
        'leconDate'   => null,
        'leconHeure'   => null,
        'eleveNum'   => null,
        'moniNum'   => null,
    );

}
