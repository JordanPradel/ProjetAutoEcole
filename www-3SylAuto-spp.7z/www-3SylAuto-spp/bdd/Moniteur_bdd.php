<?php
include_once('bdd.php');
/**
 * Auteur: Jordan PRADEL & Steven SALANDINI
 */
class Moniteur_bdd extends Model
{
	public $cnx;
	public $identifiant;

	public $model_name = 'moniteur';

	public $id_name = 'moniNum';

    protected $champs = array(
        'moniNum'     => null,
        'moniNom'   => null,
        'moniPrenom'   => null,
        'moniAdr' => null,
        'moniCP'   => null,
        'moniVille'   => null,
        'voitNum'   => null,
    );


	public function __construct($param_identifiant)
	{
		parent::__construct();

		$this->identifiant = $param_identifiant;
		//Connection à la BDD
		$this->connexion_oci();
	}

	/**
	 * BDD destructeur
	 */
	function __destruct()
	{
		//Déconnection de la BDD
		$this->deconnexion_oci();
	}


	/**
	 * Récupère le nom et le prénom d'un moniteur en fonction de son identifiant
	 */
	public function getNomMoniteur(){

		/* Requête pour la recherche en base de données */
		$requete1 = "Select moniNom, moniPrenom
					 FROM moniteur
					 Where moniNum = '".$this->identifiant."'";
		$requete_parse = oci_parse($this->cnx, $requete1);
		$resultat1= oci_execute($requete_parse);

		if($resultat1) {

			$ligne_courante = oci_fetch_array($requete_parse);
			return $ligne_courante[0].' '.$ligne_courante[1];
		}else {
			echo '<script>alert("GetNomMoniteur erreur")</script>';
		}
	}

	/**
	 * Récupère la liste des informations du moniteur
	 */
	public function getInformations(){

		$requete1 = "SELECT moniNom, moniPrenom, moniAdr, moniCP,
							moniVille, moniTelFixe, moniTelMob
					FROM moniteur
					WHERE moniNum = ".$this->identifiant;

		$requete_parse = oci_parse($this->cnx, $requete1);
		$resultat1 = oci_execute($requete_parse);
		if ($resultat1) {
			$ligne_courante=oci_fetch_array($requete_parse);
			/* Récupération des informations pour les mettre dans un tableau */
			$informations = array(
				"moniNom" => $ligne_courante[0],
				"moniPrenom" => $ligne_courante[1],
				"moniAdr" => $ligne_courante[2],
				"moniCP" => $ligne_courante[3],
				"moniVille" => $ligne_courante[4],
				"moniTelFixe" => $ligne_courante[5],
				"moniTelMob" => $ligne_courante[6]
			);
		}


		if (isset($informations)) {
			return $informations; // on renvoie le tableau
		} else {
			echo '<br/>Aucune information trouvée<br/>';
		}
	}

	/**
	 * Récupère la liste des informations de tous les élèves du moniteur
	 */
	public function getListeEleves(){

		$requete1 = "SELECT eleveNom, elevePrenom, eleveAdr, eleveCP,
							eleveVille, eleveNaiss, eleveTelFixe, eleveTelMob,
							eleveNbTickets, cliNum, formNum
					FROM eleve
					WHERE moniNum = ".$this->identifiant;

		$requete_parse = oci_parse($this->cnx, $requete1);
		$resultat1 = oci_execute($requete_parse);
		$nbEleves = 0;
		if ($resultat1) {
			/* Récupération des informations pour les mettre dans un tableau */
			while ($ligne_courante=oci_fetch_array($requete_parse)) {
				$informations = array(
					"eleveNom" => $ligne_courante[0],
					"elevePrenom" => $ligne_courante[1],
					"eleveAdr" => $ligne_courante[2],
					"eleveCP" => $ligne_courante[3],
					"eleveVille" => $ligne_courante[4],
					"eleveNaiss" => $ligne_courante[5],
					"eleveTelFixe" => $ligne_courante[6],
					"eleveTelMob" => $ligne_courante[7],
					"eleveNbTickets" => $ligne_courante[8],
					"cliNum" => $ligne_courante[9],
					"formNum" => $ligne_courante[10]
				);
				$liste_eleves[$nbEleves] = $informations;
				$nbEleves++;
			}


			if (isset($liste_eleves)) {
				return $liste_eleves; // on renvoie le tableau
			} else {
				echo '<br/>Aucune information trouvée<br/>';
			}
		}
	}

	public function getAllMoniteur(){
		$requete1 = "SELECT moniNum,moniNom,moniPrenom
					 FROM moniteur";
		$requete_parse = oci_parse($this->cnx, $requete1);
		$resultat1 = oci_execute($requete_parse);
		$i=0;
		while($ligne_courante=oci_fetch_array($requete_parse)){
			$informations[$i] = array(
				"moniNum" => $ligne_courante[0],
				"moniNom" => $ligne_courante[1],
				"moniPrenom" => $ligne_courante[2],
			);
			$i++;
		}
		return $informations;
	}

}