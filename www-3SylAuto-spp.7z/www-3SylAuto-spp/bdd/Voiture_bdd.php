<?php
include_once 'bdd.php';
/**
 * Auteur: Colin PEREMARTY
 */
class Voiture_bdd extends Model
{
    public $model_name = 'voiture';

    public $id_name = 'voitNum';

    protected $champs = array(
        'voitNum'     => null,
        'voitImmat'   => null,
        'voitKm'   => null,
        'modeleNum' => null,
    );



}