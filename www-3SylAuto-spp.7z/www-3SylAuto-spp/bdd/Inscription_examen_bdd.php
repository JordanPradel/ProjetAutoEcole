<?php
include_once 'bdd.php';
/**
 * Auteur: Colin PEREMARTY
 */
class Inscription_examen_bdd extends Model
{
    public $model_name = 'inscription_examen';

    public $id_name = 'inscExamNum';

    protected $champs = array(
        'inscExamNum'     => null,
        'eleveNum'   => null,
        'examNum'   => null,
    );

}