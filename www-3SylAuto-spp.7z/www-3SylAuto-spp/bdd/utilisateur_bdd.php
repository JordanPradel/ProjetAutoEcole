<?php
	include_once('bdd.php');
	/**
	 * Auteur: Jordan PRADEL
	 */
	class Utilisateur_bdd extends Model
	{
		public $cnx;


		public $id_name = 'utilNum';

		public function __construct()
		{
			parent::__construct();

			//Connection à la BDD
			$this->connexion_oci();
		}

		/**
		 * BDD destructeur
		 */
		function __destruct()
		{
			//Déconnection de la BDD
			$this->deconnexion_oci();
		}

		/*
		 * Cette fonction renvoie l'id de l'utilisateur s'il existe en base de données
		 */
		public function connexion($param_login, $param_mdp){

			$login_utilisateur;
			$profil_utilisateur;
			$identifiant_utilisateur;

			/* Requete pour récupérer les mails et les passwords */
			$requete1 = "SELECT login, mdp, profil, identifiant FROM utilisateur";
			$requete1_parse = oci_parse($this->cnx, $requete1);
			$resultat1 = oci_execute($requete1_parse);
			
			/* Curseur pour rechercher le login et le mot de passe passés en paramètre */
			while($ligne_courante=oci_fetch_object($requete1_parse)) {
				/* Si le login et le mot de passe sont trouvés, on renvoie l'id utilisateur */
				if ($ligne_courante->LOGIN == $param_login && $ligne_courante->MDP == $param_mdp) {
					$login_utilisateur = $ligne_courante->LOGIN;
					$profil_utilisateur = $ligne_courante->PROFIL;
					$identifiant_utilisateur = $ligne_courante->IDENTIFIANT;
				}
			}
			if(isset($login_utilisateur)) {
				echo '<script>alert("Connexion réussie")</script>';
				$this->initialisationSession($login_utilisateur, $profil_utilisateur, $identifiant_utilisateur);
				echo $profil_utilisateur;
				if ($profil_utilisateur == "eleve" || $profil_utilisateur == "moniteur") {
								$redirect = 'Location: ' . $GLOBALS['site_url'] . 'agendas/lecons_conduite.php';
				} else if ($profil_utilisateur == "secretaire") {
								$redirect = 'Location: ' . $GLOBALS['site_url'] . 'secretaire.php';
				}
				header($redirect, true);
			}
			else {
				echo '<script>alert("Problème lors de la saisie")</script>';
			}

		}

		/*
		 * Cette fonction renvoie le nom et le prénom de l'utilisateur connecté
		 */
		public function getNomPrenom(){
			if(isset($_SESSION["profil"])) {
				$nom_utilisateur;
				$prenom_utilisateur;

				/* Requete pour récupérer les mails et les passwords */

				switch($_SESSION["profil"]){
					case 'eleve':
						$requete1 = "SELECT eleveNom, elevePrenom FROM eleve WHERE eleveNum = '" . $_SESSION["identifiant"] . "'";
					break;
					case 'moniteur':
						$requete1 = "SELECT moniNom, moniPrenom FROM moniteur WHERE moniNum = '" . $_SESSION["identifiant"] . "'";
					break;
					case 'secretaire':
						$requete1 = "SELECT secretNom, secretPrenom FROM secretaire WHERE secretNum = '" . $_SESSION["identifiant"] . "'";
					break;
					default:
						//Redirection vers la page d'accueil
						$redirect ='Location: ' . $GLOBALS['site_url'] . 'session/deconnexion.php';
						header($redirect, true);
					break;
				}

//				 var_dump($_SESSION);
//				 die('die');
				$requete_parse = oci_parse($this->cnx, $requete1);
				$resultat1 = oci_execute($requete_parse);

				/* Curseur pour rechercher le login et le mot de passe passés en paramètre */
				$ligne_courante = oci_fetch_array($requete_parse);
				$nom_prenom = $ligne_courante[0] . ' ' . $ligne_courante[1];

				if ($nom_prenom) {
					return $nom_prenom;
				} else {
					echo '<script>alert("GetNomPrenom erreur")</script>';
				}
			}
			//Redirection vers la page d'accueil
			$redirect ='Location: ' . $GLOBALS['site_url'] . 'session/connexion.php';
			header($redirect, true);
		}

		/**
		 * Cette fonction initialise les variables de la session en fonction de l'utilisateur connecté
		 */
		private function initialisationSession($param_login, $param_profil, $param_identifiant){
			$_SESSION['login'] = $param_login;
			$_SESSION['profil'] = $param_profil;
			$_SESSION['identifiant'] = $param_identifiant;
			$_SESSION['duree_lecon_code'] = 1;
			$_SESSION['heure_ouverture'] = 7;
			$_SESSION['heure_fermeture'] = 19;
		}

		/**
		 * Cette fonction permet d'inscrire un nouvel utilisateur
		 * en l'ajoutant dans la base de données
		 */
		public function inscription($param_login, $param_mdp, $param_profil, $param_identifiant) {

			/* Requête pour l'insertion en base de données */
			$requete1 = "INSERT INTO utilisateur (login, mdp, profil, identifiant)
									 VALUES ('".$param_login."', '".$param_mdp."', '".$param_profil."', '".$param_identifiant."')";
			$requete_parse = oci_parse($this->cnx, $requete1);
			$resultat1= oci_execute($requete_parse);
			if($resultat1) {
				echo '<script>alert("Inscription réussie")</script>';
				$redirect = 'Location: ' . $GLOBALS['site_url'] . 'index.php';
				header($redirect, true);
			}
			else {
				echo '<script>alert("Problème lors de la saisie")</script>';
			}

		}
	}
?>