<?php
include_once 'bdd.php';
/**
 * Auteur: Colin PEREMARTY
 */
class Resultat_examen_bdd extends Model
{
    public $model_name = 'resultat_examen';


    public $id_name = '';

    protected $champs = array(
        'eleveNum'     => null,
        'examNum'   => null,
        'resultat'   => null,
    );

}