<?php
include_once 'bdd.php';
/**
 * Auteur: Steven SALANDINI
 */
class Formule_bdd extends Model
{
	public $cnx;
    public $model_name = 'formule';

    protected $champs = array(
        'formNum'     => null,
        'formForfait'   => null,
        'formNbTickets'   => null,
        'formPrixUnitaireTicket' => null,
    );
	
	public function __construct()
	{
		parent::__construct();
		//Connection à la BDD
		$this->connexion_oci();
	}

	/**
	 * BDD destructeur
	 */
	function __destruct()
	{
		//Déconnection de la BDD
		$this->deconnexion_oci();
	}
	
	public function getAllFormule (){
		
		$requete1 = "SELECT formNum,formForfait,formNbTickets,formPrixUnitaireTicket
					 FROM formule";
		$requete_parse = oci_parse($this->cnx, $requete1);
		$resultat1 = oci_execute($requete_parse);	
		$i=0;
		while($ligne_courante=oci_fetch_array($requete_parse)){
			$informations[$i] = array(
					"formNum" => $ligne_courante[0], 
					"formForfait" => $ligne_courante[1], 
					"formNbTickets" => $ligne_courante[2],
					"formPrixUnitaireTicket" => $ligne_courante[3],
			);
			$i++;
		}
		return $informations;
	}

}