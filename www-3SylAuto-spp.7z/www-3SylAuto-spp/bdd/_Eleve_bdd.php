<?php
include_once('bdd.php');
/**
 * Auteur: Jordan PRADEL
 */
class Eleve_bdd extends Model
{
	public $cnx;
	public $identifiant;
    protected $champs = array(
        'eleveNum'       => null,
        'eleveNom'       => null,
        'elevePrenom'    => null,
        'eleveAdr'       => null,
        'eleveCP'        => null,
        'eleveVille'     => null,
        'eleveNaiss'     => null,
        'eleveTelFixe'   => null,
        'eleveTelMob'    => null,
        'eleveNbTickets' => null,
        'cliNum'         => null,
        'moniNum'        => null,
        'formNum'        => null,

    );



	/**
     * Constructeur
     */
	public function __construct($param_identifiant)
	{

		parent::__construct();

		$this->identifiant = $param_identifiant;

		//Connection à la BDD
		$this->connexion_mysql();
	}

	/**
	 * BDD destructeur
	 */
	function __destruct()
	{
		//Déconnection de la BDD
		$this->deconnexion_mysql();
	}


	/**
	 * Récupère le nom et le prénom d'un élève en fonction de son identifiant
	 */
	public function getNomEleve(){

		/* Requête pour la recherche en base de données */
		$requete1 = "SELECT eleveNom, elevePrenom
					 FROM eleve
					 WHERE eleveNum = '".$this->identifiant."'";
		$resultat1= mysql_query($requete1);

		if($resultat1) {

			$ligne_courante = mysql_fetch_array($resultat1);
			return $ligne_courante[0].' '.$ligne_courante[1];
		}else {
			echo '<script>alert("GetNomEleve erreur")</script>';
		}
	}

	/**
	 * Cette fonction permet de récupérer les informations d'un élève
	 */
	public function getInformations() {

		$requete1 = "SELECT eleveNom, elevePrenom, eleveAdr, eleveCP,
							eleveVille, eleveNaiss, eleveTelFixe, eleveTelMob,
							eleveNbTickets, cliNum, moniNum, formNum
					FROM eleve
					WHERE eleveNum = ".$this->identifiant;


		$resultat1 = mysql_query($requete1);

		if ($resultat1) {
			/* Récupération des informations pour les mettre dans un tableau */
			$ligne_courante=mysql_fetch_array($resultat1);
			$informations = array(
				"eleveNom" => $ligne_courante[0],
				"elevePrenom" => $ligne_courante[1],
				"eleveAdr" => $ligne_courante[2],
				"eleveCP" => $ligne_courante[3],
				"eleveVille" => $ligne_courante[4],
				"eleveNaiss" => $ligne_courante[5],
				"eleveTelFixe" => $ligne_courante[6],
				"eleveTelMob" => $ligne_courante[7],
				"eleveNbTickets" => $ligne_courante[8],
				"cliNum" => $ligne_courante[9],
				"moniNum" => $ligne_courante[10],
				"formNum" => $ligne_courante[11]
			);

			if (isset($informations)) {
				return $informations; // on renvoie le tableau
			} else {
				echo '<br/>Aucune information trouvée<br/>';
			}
		}

	}
}