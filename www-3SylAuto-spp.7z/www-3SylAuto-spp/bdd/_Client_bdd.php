<?php
include_once('bdd.php');
class Client_bdd extends Model
{
	public $cnx;
	public $identifiant;
    protected $champs = array(
        'cliNum' => null,
        'cliNom' => null,
        'cliPrenom' => null,
        'cliAdr' => null,
        'cliCP' => null,
        'cliVille' => null,
        'cliTelFixe' => null,
        'cliTelMob' => null,
    );


	public function __construct($param_identifiant)
	{
		parent::__construct();

		$this->identifiant = $param_identifiant;

		$this->connexion_mysql();

	}

	/**
	 * BDD destructeur
	 */
	function __destruct()
	{
		//Déconnection de la BDD
		$this->deconnexion_mysql();
	}


	/**
	 * Récupère le nom et le prénom d'un client en fonction de son identifiant
	 */
	public function getNomClient(){

		/* Requête pour la recherche en base de données */
		$requete1 = "SELECT cliNom, cliPrenom
					 FROM client
					 WHERE cliNum = ".$this->identifiant;
		$resultat1= mysql_query($requete1);

		if($resultat1) {

			$ligne_courante = mysql_fetch_array($resultat1);
			return $ligne_courante[0].' '.$ligne_courante[1];
		}else {
			echo '<script>alert("GetNomClient erreur")</script>';
		}
	}

	/**
	 * Récupère la liste des informations du client
	 */
	public function getInformations(){

		$requete1 = "SELECT cliNom, cliPrenom, cliAdr, cliCP,
							cliVille, cliTelFixe, cliTelMob
					FROM client
					WHERE cliNum = ".$this->identifiant;


		$resultat1 = mysql_query($requete1);
		if ($resultat1) {
			$ligne_courante=mysql_fetch_array($resultat1);
			/* Récupération des informations pour les mettre dans un tableau */
			$informations = array(
				"cliNom" => $ligne_courante[0],
				"cliPrenom" => $ligne_courante[1],
				"cliAdr" => $ligne_courante[2],
				"cliCP" => $ligne_courante[3],
				"cliVille" => $ligne_courante[4],
				"cliTelFixe" => $ligne_courante[5],
				"cliTelMob" => $ligne_courante[6]
			);
		}


		if (isset($informations)) {
			return $informations; // on renvoie le tableau
		} else {
			echo '<br/>Aucune information trouvée<br/>';
		}
	}

	/**
	 * Récupère la liste des informations de tous les élèves du client
	 */
	public function getListeEleves(){

		$requete1 = "SELECT eleveNom, elevePrenom, eleveAdr, eleveCP,
							eleveVille, eleveNaiss, eleveTelFixe, eleveTelMob,
							eleveNbTickets, moniNum, formNum
					FROM eleve
					WHERE cliNum = ".$this->identifiant;


		$resultat1 = mysql_query($requete1);
		$nbEleves = 0;
		if ($resultat1) {
			/* Récupération des informations pour les mettre dans un tableau */
			while ($ligne_courante=mysql_fetch_array($resultat1)) {
				$informations = array(
					"eleveNom" => $ligne_courante[0],
					"elevePrenom" => $ligne_courante[1],
					"eleveAdr" => $ligne_courante[2],
					"eleveCP" => $ligne_courante[3],
					"eleveVille" => $ligne_courante[4],
					"eleveNaiss" => $ligne_courante[5],
					"eleveTelFixe" => $ligne_courante[6],
					"eleveTelMob" => $ligne_courante[7],
					"eleveNbTickets" => $ligne_courante[8],
					"moniNum" => $ligne_courante[9],
					"formNum" => $ligne_courante[10]
				);
				$liste_eleves[$nbEleves] = $informations;
				$nbEleves++;
			}


			if (isset($liste_eleves)) {
				return $liste_eleves; // on renvoie le tableau
			} else {
				echo '<br/>Aucune information trouvée<br/>';
			}
		}
	}

}