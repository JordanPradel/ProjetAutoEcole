<?php
	include_once('bdd.php');
	/**
	 * Auteur: Steven SALANDINI
	 */
	class Secretaire_bdd extends Model
	{
		public $cnx;

		public function __construct()
		{
			parent::__construct();

			//Connection à la BDD
			$this->connexion_oci();
		}

		/**
		 * BDD destructeur
		 */
		function __destruct()
		{
			//Déconnection de la BDD
			$this->deconnexion_oci();
		}



		public function getListEleves(){

			/* Requ�te pour l'insertion en base de donn�es */
			$requete1 = "Select eleveNum, eleveNom, elevePrenom, eleveNbTickets,cliNom
						 FROM eleve,client
						 Where client.cliNum = eleve.cliNum";
			$requete_parse = oci_parse($this->cnx, $requete1);
			$resultat1= oci_execute($requete_parse);

			if($resultat1) {
				$i=0;
				while($resultat = oci_fetch_object($requete_parse)){
					$row[$i]= array(
						"eleveNum" => $resultat -> ELEVENUM,
						"eleveNom" => $resultat -> ELEVENOM,
						"elevePrenom" => $resultat -> ELEVEPRENOM,
						"eleveNbTicket" => $resultat -> ELEVENBTICKETS,
						"cliNom" => $resultat -> CLINOM
					);
					$i++;
				}
				return $row;
			}else {
				echo '<script>alert("Probl�me lors de la saisie")</script>';
			}
		}

		public function getListClients(){

			/* Requ�te pour l'insertion en base de donn�es */
			$requete1 = "Select cliNum, cliNom, cliPrenom, cliCP,cliVille
						 FROM client";
			$requete_parse = oci_parse($this->cnx, $requete1);
			$resultat1= oci_execute($requete_parse);

			if($resultat1) {
				$i=0;
				while($resultat = oci_fetch_object($requete_parse)){
					$row[$i]= array(
						"cliNum" => $resultat -> CLINUM,
						"cliNom" => $resultat -> CLINOM,
						"cliPrenom" => $resultat -> CLIPRENOM,
						"cliCP" => $resultat -> CLICP,
						"cliVille" => $resultat -> CLIVILLE
					);
					$i++;
				}
				return $row;
			}else {
				echo '<script>alert("Probl�me lors de la saisie")</script>';
			}
		}

		public function getListMoniteurs(){

			/* Requ�te pour l'insertion en base de donn�es */
			$requete1 = "Select moniNum, moniNom, moniPrenom, voitImmat,modeleNom
						 FROM moniteur, voiture, modele
						 WHERE moniteur.voitNum = voiture.voitNum
						 AND voiture.modeleNum = modele.modeleNum";
			$requete_parse = oci_parse($this->cnx, $requete1);
			$resultat1= oci_execute($requete_parse);

			if($resultat1) {
				$i=0;
				while($resultat = oci_fetch_object($requete_parse)){
					$row[$i]= array(
						"moniNum" => $resultat -> MONINUM,
						"moniNom" => $resultat -> MONINOM,
						"moniPrenom" => $resultat -> MONIPRENOM,
						"voitImmat" => $resultat -> VOITIMMAT,
						"modeleNom" => $resultat -> MODELENOM
					);
					$i++;
				}
				return $row;
			}else {
				echo '<script>alert("Probl�me lors de la saisie")</script>';
			}
		}
	}
?>