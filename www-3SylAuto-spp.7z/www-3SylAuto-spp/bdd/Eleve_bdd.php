<?php
include_once('bdd.php');
/**
 * Auteur: Jordan PRADEL & Steven SALANDINI
 */
class Eleve_bdd extends Model
{
	public $cnx;
	public $identifiant;

	public $model_name = 'eleve';

	public $id_name = 'eleveNum';

    protected $champs = array(
        'eleveNum'       => null,
        'eleveNom'       => null,
        'elevePrenom'    => null,
        'eleveAdr'       => null,
        'eleveCP'        => null,
        'eleveVille'     => null,
        'eleveNaiss'     => null,
        'eleveTelFixe'   => null,
        'eleveTelMob'    => null,
        'eleveNbTickets' => null,
        'cliNum'         => null,
        'moniNum'        => null,
        'formNum'        => null,

    );



	/**
     * Constructeur
     */
	public function __construct($param_identifiant)
	{
		parent::__construct();

		$this->identifiant = $param_identifiant;

		//Connection à la BDD
		$this->connexion_oci();
	}

	/**
	 * BDD destructeur
	 */
	function __destruct()
	{
		//Déconnection de la BDD
		$this->deconnexion_oci();
	}


	/**
	 * Récupère le nom et le prénom d'un élève en fonction de son identifiant
	 */
	public function getNomEleve(){

		/* Requête pour la recherche en base de données */
		$requete1 = "SELECT eleveNom, elevePrenom
					 FROM eleve
					 WHERE eleveNum = '".$this->identifiant."'";
		$requete_parse = oci_parse($this->cnx, $requete1);
		$resultat1= oci_execute($requete_parse);

		if($resultat1) {

			$ligne_courante = oci_fetch_array($requete_parse);
			return $ligne_courante[0].' '.$ligne_courante[1];
		}else {
			echo '<script>alert("GetNomEleve erreur")</script>';
		}
	}

	/**
	 * Cette fonction permet de récupérer les informations d'un élève
	 */
	public function getInformations() {

		$requete1 = "SELECT eleveNum, eleveNom, elevePrenom, eleveAdr, eleveCP,
							eleveVille, eleveNaiss, eleveTelFixe, eleveTelMob,
							eleveNbTickets, cliNum, moniNum, eleve.formNum, formForfait,formPrixUnitaireTicket
					FROM eleve ,formule
					WHERE eleveNum = ".$this->identifiant."
					AND eleve.formNum = formule.formNum";

		$requete_parse = oci_parse($this->cnx, $requete1);
		$resultat1 = oci_execute($requete_parse);

		if ($resultat1) {
			/* Récupération des informations pour les mettre dans un tableau */
			$ligne_courante=oci_fetch_array($requete_parse);
			$informations = array(
				"eleveNum" => $ligne_courante[0],
				"eleveNom" => $ligne_courante[1],
				"elevePrenom" => $ligne_courante[2],
				"eleveAdr" => $ligne_courante[3],
				"eleveCP" => $ligne_courante[4],
				"eleveVille" => $ligne_courante[5],
				"eleveNaiss" => $ligne_courante[6],
				"eleveTelFixe" => $ligne_courante[7],
				"eleveTelMob" => $ligne_courante[8],
				"eleveNbTickets" => $ligne_courante[9],
				"cliNum" => $ligne_courante[10],
				"moniNum" => $ligne_courante[11],
				"formNum" => $ligne_courante[12],
				"formForfait" => $ligne_courante[13],
				"formPrixUnitaireTicket" => $ligne_courante[14]
			);

			if (isset($informations)) {
				return $informations; // on renvoie le tableau
			} else {
				echo '<br/>Aucune information trouvée<br/>';
			}
		}

	}

	public function AddNewEleve($eleveNom,$elevePrenom,$eleveAdr,$eleveCP,$eleveVille,$eleveNaiss,$eleveTelFixe,$eleveTelMob,$eleveNbTickets,$cliNum,$moniNum,$formNum){
		$requete1 = "INSERT INTO eleve (eleveNom, elevePrenom, eleveAdr, eleveCP, eleveVille, eleveNaiss,eleveTelFixe,eleveTelMob,eleveNbTickets,cliNum,moniNum,formNum)
 VALUES ('".$eleveNom."','".$elevePrenom."','".$eleveAdr."','".
			$eleveCP."','".$eleveVille."','".$eleveNaiss."','".$eleveTelFixe."','".
			$eleveTelMob."',".$eleveNbTickets.",".$cliNum.",".$moniNum.",".$formNum.")";
		
		$requete_parse = oci_parse($this->cnx, $requete1);
		$resultat1 = oci_execute($requete_parse);
	}

	public function ModifierEleve($eleveNum,$eleveNom,$elevePrenom,$eleveAdr,$eleveCP,$eleveVille,$eleveNaiss,$eleveTelFixe,$eleveTelMob,$eleveNbTickets,$cliNum,$moniNum,$formNum){

		$requete1 = "UPDATE eleve
SET eleveNom = '".$eleveNom."',
	elevePrenom = '".$elevePrenom."',
	eleveAdr = '".$eleveAdr."',
	eleveCP = '".$eleveCP."',
	eleveNaiss = '".$eleveNaiss."',
	eleveVille = '".$eleveVille."',
	eleveTelFixe = '".$eleveTelFixe."',
	eleveTelMob = '".$eleveTelMob."',
	eleveNbTickets = ".$eleveNbTickets.",
	moniNum = ".$moniNum.",
	cliNum = ".$cliNum.",
	formNum = ".$formNum."
WHERE eleveNum = ".$eleveNum;
		$requete_parse = oci_parse($this->cnx, $requete1);
		$resultat1 = oci_execute($requete_parse);
	}

	public function addTicket($numEleve,$nbTicket){
		$requete1 = "UPDATE eleve SET eleveNbTickets = eleveNbTickets + ".$nbTicket." WHERE eleveNum = ".$numEleve;
		
		$requete_parse = oci_parse($this->cnx, $requete1);
		oci_execute($requete_parse);
		$requete1 = "INSERT INTO achat_ticket (nbAchatTicket,dateAchatTicket,numEleve)
					 VALUES (".$nbTicket.",DATE(NOW()),".$numEleve.")";
		$requete_parse = oci_parse($this->cnx, $requete1);
		oci_execute($requete_parse);
	}

	public function getFactureEleve(){

		$requete1 = "SELECT dateAchatTicket,nbAchatTicket
						FROM eleve
						LEFT OUTER JOIN achat_ticket ON eleve.eleveNum = achat_ticket.numEleve
						WHERE eleve.eleveNum = ".$this->identifiant;


		$requete_parse = oci_parse($this->cnx, $requete1);
		$resultat1 = oci_execute($requete_parse);

		if ($resultat1) {
			/* Récupération des informations pour les mettre dans un tableau */
			$i=0;
			while($ligne_courante=oci_fetch_array($requete_parse)){
				$informations[$i] = array(
					"dateAchatTicket" => $ligne_courante[0],
					"nbAchatTicket" => $ligne_courante[1]
				);
				$i++;
			}
			if (isset($informations)) {
				return $informations; // on renvoie le tableau
			} else {
				echo '<br/>Aucune information trouvée<br/>';
			}
		}
	}
}