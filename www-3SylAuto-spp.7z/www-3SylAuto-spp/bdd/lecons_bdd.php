<?php
	include_once('bdd.php');
	/**
	 * Auteur: Jordan PRADEL
	 */
	class Liste_Lecon extends Model
	{
		public $cnx;

		public $id_name = 'leconNum';

		public function __construct()
		{
			parent::__construct();

			//Connection à la BDD
			$this->connexion_oci();
		}

		/**
		 * BDD destructeur
		 */
		function __destruct()
		{
			//Déconnection de la BDD
			$this->deconnexion_oci();
		}

		/**
		 * Cette fonction permet de récupérer les leçons d'un profil
		 */
		public function liste_lecons_profil($param_profil, $param_identifiant) {

			/* Requête pour récupérer les albums */
			if ($param_profil == "eleve") {
				$requete1 = "SELECT leconDate, leconHeure, moniNum FROM lecon_conduite WHERE eleveNum = ".$param_identifiant;
			} else if ($param_profil == "moniteur") {
				$requete1 = "SELECT leconDate, leconHeure, eleveNum FROM lecon_conduite WHERE moniNum = ".$param_identifiant;
			}else{
				$requete1 = "SELECT * FROM lecon_conduite";
			}
			$requete_parse = oci_parse($this->cnx, $requete1);
			$resultat1 = oci_execute($requete_parse);
			$nb_lecons = 0;

			if ($resultat1) {
				/* Curseur pour récupérer les informations des leçons et les mettre dans un tableau */
				while($ligne_courante=oci_fetch_array($requete_parse)) {
					// Mise des informations de la leçon courante dans un tableau
					$lecon_courante = array(
						"leconDate" => $ligne_courante[0],
						"leconHeure" => $ligne_courante[1],
						"identifiant" => $ligne_courante[2]
					);
					$liste_lecons[$nb_lecons] = $lecon_courante;
					$nb_lecons++;
				}
				if (isset($liste_lecons)) {
					return $liste_lecons; // on renvoie le tableau
				}
			}

		}

		/**
		 * Cette fonction permet de savoir si une leçon d'une liste existe à une date
		 */
		public function lecon_existe_a_date($param_liste_lecons, $param_jour, $param_mois, $param_an) {
			$i = 0;
			for ($i; $i<count($param_liste_lecons); $i++) {
				$lecon_courante = $param_liste_lecons[$i];
				if ($lecon_courante["leconDate"] == $param_an."-".$param_mois."-".$param_jour) {
					return true;
				}
			}
		}

		/**
		 * Cette fonction permet de savoir si une leçon d'une liste existe à une heure
		 */
		public function lecon_existe_a_heure($param_liste_lecons, $param_heure) {
			$i = 0;
			for ($i; $i<count($param_liste_lecons); $i++) {
				$lecon_courante = $param_liste_lecons[$i];
				if ($lecon_courante["leconHeure"] == $param_heure) {
					return true;
				}
			}
		}

		/**
		 * Cette fonction permet de récupérer dates/heures des leçons de code
		 */
		public function liste_lecons_code() {

			/* Requête pour récupérer les albums */
			$requete1 = "SELECT codeDate, codeHeure FROM lecon_code";
			$requete_parse = oci_parse($this->cnx, $requete1);
			$resultat1 = oci_execute($requete_parse);
			$nb_lecons = 0;

			/* Curseur pour récupérer les informations des leçons */
			while($ligne_courante=oci_fetch_object($requete_parse)) {
				// Mise des informations de la leçon courante dans un tableau
				$lecon_courante = array(
					"leconDate" => $ligne_courante->CODEDATE,
					"leconHeure" => $ligne_courante->CODEHEURE
				);
				$liste_lecons[$nb_lecons] = $lecon_courante;
				$nb_lecons++;
			}
			if (isset($liste_lecons)) {
				return $liste_lecons; // on renvoie le tableau
			} else {
				echo '<br/>Aucune leçon trouvée<br/>';
			}
		}
	}
?>