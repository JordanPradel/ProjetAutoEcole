<?php
include_once 'bdd.php';
/**
 * Auteur: Colin PEREMARTY
 */
class Lecon_code_bdd extends Model
{
    public $model_name = 'lecon_code';

    public $id_name = 'codeNum';

    protected $champs = array(
        'codeNum'     => null,
        'codeDate'   => null,
        'codeHeure'   => null,
    );

}
