<?php
include_once('bdd.php');
/**
 * Auteur: Jordan PRADEL & Steven SALANDINI
 */
class Client_bdd extends Model
{
	public $cnx;
	public $identifiant;
    protected $champs = array(
        'cliNum' => null,
        'cliNom' => null,
        'cliPrenom' => null,
        'cliAdr' => null,
        'cliCP' => null,
        'cliVille' => null,
        'cliTelFixe' => null,
        'cliTelMob' => null,
    );

	public $id_name = 'cliNum';


	public function __construct($param_identifiant)
	{
		parent::__construct();

		$this->identifiant = $param_identifiant;

		//Connection à la BDD
		$this->connexion_oci();
	}

	/**
	 * BDD destructeur
	 */
	function __destruct()
	{
		//Déconnection de la BDD
		$this->deconnexion_oci();
	}


	/**
	 * Récupère le nom et le prénom d'un client en fonction de son identifiant
	 */
	public function getNomClient(){

		/* Requête pour la recherche en base de données */
		$requete1 = "SELECT cliNom, cliPrenom
					 FROM client
					 WHERE cliNum = ".$this->identifiant;
		$requete_parse = oci_parse($this->cnx, $requete1);
		$resultat1= oci_execute($requete_parse);

		if($resultat1) {

			$ligne_courante = oci_fetch_array($requete_parse);
			return $ligne_courante[0].' '.$ligne_courante[1];
		}else {
			echo '<script>alert("GetNomClient erreur")</script>';
		}
	}

	/**
	 * Récupère la liste des informations du client
	 */
	public function getInformations(){

		$requete1 = "SELECT cliNum, cliNom, cliPrenom, cliAdr, cliCP,
							cliVille, cliTelFixe, cliTelMob
					FROM client
					WHERE cliNum = ".$this->identifiant;

		$requete_parse = oci_parse($this->cnx, $requete1);
		$resultat1 = oci_execute($requete_parse);
		if ($resultat1) {
			$ligne_courante=oci_fetch_array($requete_parse);
			/* Récupération des informations pour les mettre dans un tableau */
			$informations = array(
				"cliNum" => $ligne_courante[0],
				"cliNom" => $ligne_courante[1],
				"cliPrenom" => $ligne_courante[2],
				"cliAdr" => $ligne_courante[3],
				"cliCP" => $ligne_courante[4],
				"cliVille" => $ligne_courante[5],
				"cliTelFixe" => $ligne_courante[6],
				"cliTelMob" => $ligne_courante[7]
			);
		}


		if (isset($informations)) {
			return $informations; // on renvoie le tableau
		} else {
			echo '<br/>Aucune information trouvée<br/>';
		}
	}

	/**
	 * Récupère la liste des informations de tous les élèves du client
	 */
	public function getListeEleves(){

		$requete1 = "SELECT eleveNom, elevePrenom, eleveAdr, eleveCP,
							eleveVille, eleveNaiss, eleveTelFixe, eleveTelMob,
							eleveNbTickets, moniNum, formNum
					FROM eleve
					WHERE cliNum = ".$this->identifiant;


		$requete_parse = oci_parse($this->cnx, $requete1);
		$resultat1 = oci_execute($requete_parse);
		$nbEleves = 0;
		if ($resultat1) {
			/* Récupération des informations pour les mettre dans un tableau */
			while ($ligne_courante=oci_fetch_array($requete_parse)) {
				$informations = array(
					"eleveNom" => $ligne_courante[0],
					"elevePrenom" => $ligne_courante[1],
					"eleveAdr" => $ligne_courante[2],
					"eleveCP" => $ligne_courante[3],
					"eleveVille" => $ligne_courante[4],
					"eleveNaiss" => $ligne_courante[5],
					"eleveTelFixe" => $ligne_courante[6],
					"eleveTelMob" => $ligne_courante[7],
					"eleveNbTickets" => $ligne_courante[8],
					"moniNum" => $ligne_courante[9],
					"formNum" => $ligne_courante[10]
				);

				$liste_eleves[$nbEleves] = $informations;
				$nbEleves++;
			}


			if (isset($liste_eleves)) {
				return $liste_eleves; // on renvoie le tableau
			} else {
				echo '<br/>Aucune information trouvée<br/>';
			}
		}
	}

	public function AddNewClient($cliNom,$cliPrenom,$cliAdr,$cliCP,$cliVille,$cliTelFixe,$cliTelMob){
		$requete1 = "INSERT INTO client (cliNom, cliPrenom, cliAdr, cliCP, cliVille, cliTelFixe,cliTelMob)
 VALUES ('".$cliNom."','".$cliPrenom."','".$cliAdr."','".
			$cliCP."','".$cliVille."','".$cliTelFixe."','".
			$cliTelMob."')";
		$resultat1 = oci_execute($requete1);
	}

	public function ModifierClient($cliNum,$cliNom,$cliPrenom,$cliAdr,$cliCP,$cliVille,$cliTelFixe,$cliTelMob){

		$requete1 = "UPDATE client
SET cliNom = '".$cliNom."',
	cliPrenom = '".$cliPrenom."',
	cliAdr = '".$cliAdr."',
	cliCP = '".$cliCP."',
	cliVille = '".$cliVille."',
	cliTelFixe = '".$cliTelFixe."',
	cliTelMob = '".$cliTelMob."'
WHERE cliNum = ".$cliNum;
		echo $requete1;
		$resultat1 = oci_execute($requete1);
	}

	public function getAllClient (){

		$requete1 = "SELECT cliNum,cliNom,cliPrenom
					 FROM client";
		$requete_parse = oci_parse($this->cnx, $requete1);
		$resultat1 = oci_execute($requete_parse);
		$i=0;
		while($ligne_courante=oci_fetch_array($requete_parse)){
			$informations[$i] = array(
				"cliNum" => $ligne_courante[0],
				"cliNom" => $ligne_courante[1],
				"cliPrenom" => $ligne_courante[2],
			);
			$i++;
		}
		return $informations;
	}
}