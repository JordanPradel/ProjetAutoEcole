<?php
include_once 'bdd.php';
/**
 * Auteur: Colin PEREMARTY
 */
class Examen_bdd extends Model
{
    public $model_name = 'examen';

    public $id_name = 'examNum';

    protected $champs = array(
        'examNum'     => null,
        'examDate'   => null,
        'examType'   => null,
    );

}