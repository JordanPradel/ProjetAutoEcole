<?php
/**
 * Auteur: Colin PEREMARTY
 */
class BDD
{
    private $bdd;
    private $model_name;
    private $id_name;
    private $database_name = 'ae';

    public $models;

    /**
     * BDD constructor.
     */
    public function __construct($model_name, $id_name)
    {
        //Connection à la BDD
        $this->connexion_bdd();
        $this->model_name = $model_name;
        $this->id_name = $id_name;
    }

    /**
     * BDD destructeur
     */
    function __destruct()
    {
        //Déconnection de la BDD
        $this->deconnexion_bdd();
    }

    /**
     * Connexion à la BDD
     */
    protected function connexion_bdd()
    {
        //echo ' connexion_bdd ';
        $this->bdd = oci_connect('spp','spp', 'BD10');
        if (!$this->bdd) {
            echo 'ErreurBDD : ' . oci_error();

            return -1;
        }
        return true;
    }

    /**
     * Deconnexion de la BDD
     */
    protected function deconnexion_bdd()
    {
        oci_close($this->bdd);
    }

    /**
     * Protege le texte d'une injection sql
     * @return string
     */
    /*public function escape_string($texte)
    {
        if (get_magic_quotes_gpc()) {
            $texte_protege = mysql_real_escape_string($this->bdd, stripslashes($texte));
        } else {
            $texte_protege = mysqli_real_escape_string($this->bdd, $texte);
        }

        return $texte_protege;
    }*/

    ////////////

    /**
     * Crée une entrée dans la table, contenant les données $datas
     *
     * @param $donnees
     * @return bool
     */
    public function create($datas)
    {
        unset($datas[$this->id_name]);
        $requete = 'INSERT INTO ' . $this->model_name . ' (';
        foreach ($datas as $nom => $data) {
            if (!is_null($data)) {
                $requete .= "`" . $this->escape_string($nom) . "`, ";
            }
        }
        unset($data);
        $requete = substr($requete, 0, -2);
        $requete .= ") VALUES (";
        foreach ($datas as $data) {
            if (!is_null($data)) {
                $requete .= "'" . $this->escape_string($data) . "', ";
            }
        }
        $requete = substr($requete, 0, -2);
        $requete .= ");";
		$requete1_parse = oci_parse($this->bdd, $requete);
		$resultat = oci_execute($requete1_parse);

        //Si la requête a fonctionné
        if ($resultat) {
            return $this->read($datas);
        }

        return false;
    }

    /**
     * Recupérer le model en fonction des parametres where
     * @param $where Tableau contenant les conditions
     * @return array
     */
    public function read($where = array())
    {
        $once = false;
        $this->models = array();
        $sql = 'SELECT * FROM `' . $this->model_name .'` ';
        foreach ($where as $attribut => $value) {
            if (!is_null($value)) {

                if (!$once) {
                    $once = true;
                    $sql .= ' WHERE ' . $attribut . ' LIKE \'' . $value . '\' ';
                } else {
                    $sql .= ' AND ' . $attribut . ' LIKE \'' . $value . '\' ';
                }
            }
        }
		$requete_parse = oci_parse($this->bdd, $sql);
		$request = oci_execute($requete_parse);
//		var_dump($sql, $request);

        //Si la requête a fonctionné
        if ($request) {
            $this->models = oci_fetch_all($requete1_parse, oci_fetch_assoc($requete1_parse));
            return $this->models;
        }

        return false;
    }

    /**
     * Met à jour la table
     *
     */
    public function update($where, $datas)
    {
        unset($datas[$this->id_name]);
        $once = false;
        $sql = 'UPDATE ' . $this->model_name . ' SET ';

        foreach ($datas as $attribut => $value) {
            if (!is_null($value)) {
                if (!$once) {
                    $sql .= ' ' . $attribut . ' = \'' . $value . '\' ';
                    $once = true;
                } else {
                    $sql .= ', ' . $attribut . ' = \'' . $value . '\' ';
                }
            }
        }

        unset($attribut, $value);
        $once = false;

        foreach ($where as $attribut => $value) {
            if (!is_null($value)) {
                if (!$once) {
                    $sql .= ' WHERE ' . $attribut . ' LIKE \'' . $value . '\' ';
                    $once = true;
                } else {
                    $sql .= ' AND ' . $attribut . ' LIKE \'' . $value . '\' ';
                }
            }
        }
		$requete_parse = oci_parse($this->bdd, $sql);
        $request = oci_execute($requete_parse);
//        echo '<pre>requ : ';var_dump($sql, $request);echo '</pre>';
        //Si la requête a fonctionné
        if ($request) {
            return $this->read($where);
        }

        return false;
    }

    /**
     * Supprime un élément ciblé par where
     *
     */
    public function delete($where)
    {
        $once = false;
        $sql = 'DELETE FROM `' . $this->database_name .'`';

        foreach ($where as $attribut => $value) {
            if (!$once) {
                $sql .= ' WHERE ' . $attribut . ' LIKE \'' . $value . '\' ';
                $once = true;
            }
            $sql .= ' AND ' . $attribut . ' LIKE \'' . $value . '\' ';
        }
		$requete_parse = oci_parse($this->bdd, $sql);
        $request = oci_execute($requete_parse);

        //Si la requête a fonctionné
        if ($request) {
            return true;
        }

        return false;

    }


}


/**
 * Class Model
 */
class Model
{
    public $BDD;
    public $models;
    protected $champs;

    public $model_name;
    public  $id_name;

    public $cnx ;

    /**
     * musiques constructor.
     */
    public function __construct()
    {
        //BDD est un objet qui fais le liens avec la bdd
        //et qui contiens les actions de bases de la gestion de ressources :
        //Create, Read, Update, Delete
        $this->BDD = new BDD($this->model_name,$this->id_name );
    }

    /**
     * Connexion à la BDD avec l'interface oci
     */
    public function connexion_oci()
    {
        //Initialisation de la connexion avec oci

        //Connection à la BDD
        $this->cnx = oci_connect('spp','spp', 'BD10');
        if(!$this->cnx){
            echo 'Impossible de se connecter : ' . oci_error($this->cnx);
        }
        /* Choix de la BD */

    }

    /**
     * Deconnexion à la BDD avec l'interface oci
     */
    public function deconnexion_oci()
    {
        //Déconnection de la BDD
       // oci_close($this->cnx);
    }


    /**
     * Ajouter un élément dans la base de données
     */
    public function ajouter(array $donnees)
    {
        return $this->BDD->create($donnees);
    }

    /**
     * Récupérer plusieurs éléments dans la base de données
     */
    public function chercher(array $donnees)
    {
        return $this->BDD->read($donnees);
    }

    /**
     * Récupérer plusieurs éléments dans la base de données
     */
    public function tous()
    {
        return $this->BDD->read();
    }



    /**
     * Modifie un élément dans la base de données
     */
    public function modifier(array $where,  array $donnees)
    {
        return $this->BDD->update($where, $donnees);
    }


    /**
     * Supprimer un élément dans la base de données
     */
    public function suprimer(array $donnees)
    {
		return $this->BDD->delete($donnees);

    }



}
