<?php
include_once 'bdd.php';
/**
 * Auteur: Colin PEREMARTY
 */
class Marque_bdd extends Model
{
    public $model_name = 'marque';
    public $id_name = '';

    protected $champs = array(
        'marqueNum'     => null,
        'marqueNom'   => null,
    );

}