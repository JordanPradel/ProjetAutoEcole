<?php
include_once 'bdd.php';
/**
 * Auteur: Colin PEREMARTY
 */
class Modele_bdd extends Model
{
    public $model_name = 'modele';

    public $id_name = 'modelNum';

    protected $champs = array(
        'modeleNum'     => null,
        'modeleNom'   => null,
        'marqueNum'   => null,
    );

}