<?php
/**
 * User: Colin Peremarty
 * Date: 10/05/2016
 * Time: 10:03
 */


const TYPE_URL = 'url';
const TYPE_NUMBER = 'number';
const TYPE_DATE = 'date';
const TYPE_STRING = 'string';

const ACTION_CREATE = 'create';
const ACTION_READ = 'read';
const ACTION_UPDATE = 'update';
const ACTION_DELETE = 'delete';


/**
 * Affiche le haut de la page
 * @param array $title
 * @param array $return_buttons
 * @param array $alerts
 */
function display_page_top($title = array(), $return_buttons = array(), $alerts = array())
{
    ?>
    <div class="row">

        <div class="col-lg-12">
            <h1 class="page-header"><?php
                //Définie le titre général et le titre par défaut de la page
                if (!empty($meta_title)) {
                    echo $meta_title . ' ' . $title['short'];
                } else {
                    echo $title['long'];
                }
                ?>
            </h1>
            <?php display_alert($alerts) ?>
        </div>

        <div class="col-lg-12 align-right">
            <?php
            if (!empty($return_buttons)) {
                foreach ($return_buttons as $link => $text) {
                    ?>
                    <a href="<?php echo '#'; ?>">
                        <button class="btn" type="link"><i class="fa fa-chevron-left"></i> <?php echo $text; ?></button>
                    </a>
                <?php }
            } ?>
        </div>
    </div>

    <?php

}


/**
 * Affiche les messages d'erreur et d'informations
 * @param $alerts
 */
function display_alert()
{
    if (!empty($_SESSION['errors'])) { ?>
        <div class="alert alert-warning">

            <ul>
                    <li><?php echo $_SESSION['errors']; ?></li>
            </ul>
        </div>
        <?php
        unset($_SESSION['errors']);
    } ?>
    <?php if (!empty($_SESSION['messages'])) { ?>
    <div class="alert alert-success">
        <!--                            <div class="alert alert-info">-->
        <ul>
                <li><?php echo $_SESSION['messages']; ?></li>

        </ul>
    </div>

    <?php
    unset($_SESSION['massages']);
}
    if (!empty($_SESSION['infos'])) { ?>
        <div class="alert alert-info">
            <ul>
                    <li><?php echo $_SESSION['infos']; ?></li>
            </ul>
        </div>

        <?php
        unset($_SESSION['infos']);
    }
}

if (!function_exists('create_datatable_v2')) {
    /**
     * @param array  $params Parametres à afficher array("nom afiché" => "nom dans le Model", ... )
     *                                              + le parametre 'buttons' indique les boutons à afficher
     * @param array  $data Liste d'éléments tirés du Model
     * @param array  $model Formaté selon array('method' => $method, 'table_id' => $table_id)
     * @param string $model_name
     * @param string $datatable_class
     * @return string
     */
    function create_datatable_v2(array $params, $data, $model, $id_name = '', $datatable_class = '', $site_url)
    {
        $page_length =  10;

        $buttons = '';

        $create = false;

        $nb_column = count($params);

        // Renvoie le contenu au lieu de l'afficher
        if ($return_content = !empty($model['return'])) {
            ob_start();
        }
        // permet de ne renvoyer qu'une ligne
        $is_content_only = !empty($model['content_only']);

        //Définition des bouton liens PAR DÉFAUTS en fonction des droits de l'utilisateur sur la ressource
        // On indique * à la fin des permissions pour vérifier s'il peut faire l'action ou l'action sur ses ressources
        if (empty($params['buttons'])) {
            $buttons_array = [];
            if (true) {
                $buttons_array['Ajouter'] = 'ajouter';
            }
            if (true) {
                $buttons_array['Consulter'] = 'consulter';
            }
            if (true) {
                $buttons_array['Modifier'] = 'modifier';
            }
            if (true) {
                $buttons_array['Supprimer'] = 'supprimer';
            }
            $params['buttons'] = $buttons_array ?: [];
        }
        ?>

        <?php
        $create_label = array_keys($params['buttons'], 'ajouter');
        if (!$is_content_only) {
            if ($create_label) {
                ?>
                <div class="row ">
                    <div class="col-lg-12 align-right ">
                        <a class="btn btn-default btn-create" href="<?php echo 'ajouter.php'; ?>">
                            <?php echo $create_label[0]; ?>
                        </a>


                        <br/><br/>
                    </div>
                </div>
                <?php
                unset($params['buttons'][$create_label[0]]);
            }
        } else {
            if ($create_label) {
                unset($params['buttons'][$create_label[0]]);
            }
        } ?>
        <?php if (!$is_content_only) { ?>

        <table data-page-length='<?php echo $page_length ?>' class="table table-striped table-bordered table-hover <?php echo is_null($datatable_class) ? '' : $datatable_class ?> " id="<?php echo 'dataTable'; ?>">

        <thead>
        <tr>
            <?php
            if (!empty($params)) {
                foreach ($params as $name => $column) {
                    //Si la colonne est composé de plusieurs éléments
                    if (is_array($column)) {
                        //Si la colonne est la colonne boutons
                        if ($name == 'buttons') {
                            $buttons = $column;
                            unset($params[$name]);
                        }
                    } else {
                        echo '<th>' . $name . '</th>';
                    }
                }
            } ?>
            <td></td>
        </tr>
        </thead>
    <?php } ?>
        <?php
        if (!empty($params)) {
            foreach ($params as $name => $column) {
                //Si la colonne est composé de plusieurs éléments
                if (is_array($column)) {
                    //Si la colonne est la colonne boutons
                    if ($name == 'buttons') {
                        $buttons = $column;
                        unset($params[$name]);
                    }
                }
            }

        }
        ?>
        <?php
        //Si il y a des données à afficher
        if (!empty($data)) { ?>

            <?php if (!$is_content_only) { ?><tbody> <?php } ?>

            <?php
//            echo '<pre>';var_dump($data);die;echo '';
            foreach ($data as $key => $model_item) {
                ?>
                <tr>
                    <?php
                    if (!empty($params)) {
                        foreach ($params as $name => $column) {
                            echo '<td >';
                            //                                                        echo '<pre>';var_dump($name, $column);die;echo '';
                            //Si la columne est une liste de plusieurs éléments
                            if (!is_array($column)) {
                                //Si le parametre affiche une liste d'éléments
                                if (is_array($model_item) && array_key_exists($column, $model_item) && is_array($model_item[$column])) {

                                    //test si le tableau est composé de la valeur enregisté (id, nbr anglais, etc) ou de la valeur a à afficher ( nom,
                                    // nombre fr,etc).
                                    $col = $model_item[$column];
                                    if (isset($col['value']) || isset($col['old_value'])) {
                                        //Affiche les données qui existes parmis les deux disponibles
                                        $value = '';
                                        $old_value = '';
                                        //extrait les valeurs du tableau et remplace les variables $value et/ou $old_value
                                        extract($col);

                                        echo '<span class="' . $column . '" data-value="' . $old_value . '">';
                                        echo $value;
                                        echo '</span>';

                                    } else {
                                        //Si c'est une la colomne est une liste d'éléments
                                        echo '<ul class="' . $column . '" >';
                                        foreach ($model_item[$column] as $item) {
                                            if (is_array($item) && array_key_exists('value', $item) && array_key_exists('old_value', $item)) {
                                                echo '<li data-value="' . $item['old_value'] . '" >';
                                                echo $item['value'];
                                                echo '</li>';
                                            } elseif (!is_null($item)) {
                                                echo '<li>';
                                                echo $item;
                                                echo '</li>';
                                            }
                                        }
                                        echo '</ul>';
                                    }

                                } else {
                                    echo '<span class="' . $column . '">' . $model_item[$column] . '</span>';
                                }
                            }

                            echo '</td>';
                        }
                    }
                    ?>
                    <td>

                        <?php

                        if (!empty($buttons)) {
                            foreach ($buttons as $label => $link) {
                                if (is_array($link)) {
                                } else {
                                    ?>
                                    <a href="<?php echo $site_url.'pages/'.$model.'/'.$link.'.php?'.$id_name.'='.$model_item[$id_name]; ?>"
                                       class="btn btn-default btn-<?php echo $link; ?>">
                                        <?php echo $label; ?>
                                    </a>
                                <?php }
                            }
                        } ?>

                    </td>

                </tr>
            <?php } ?>

            <?php if (!$is_content_only) { ?></tbody> <?php } ?>

            <?php
        } else {
            ?>
            </tbody>
            <div class="alert alert-info">
                Il n'y a pas encore d'éléments.
            </div>

            <?php
        }
        ?>
        <?php if (!$is_content_only) { ?></table> <?php } ?>

        <?php
        if ($return_content) {
            return ob_get_clean();
        }
    }
}