<?php      

  include('../../assets/header.php');
  include "../../bdd/Client_bdd.php";
  if(!(ISSET($_POST['cliNum'])&&ISSET($_POST["cliNom"])&&ISSET($_POST["cliPrenom"])&&ISSET($_POST["cliAdr"])&&ISSET($_POST["cliCP"])
		&&ISSET($_POST["cliVille"])&&ISSET($_POST["cliTelFixe"])&&ISSET($_POST["cliTelMob"]))){
	  echo '<script type="text/javascript">window.alert("Erreur : Parametre invalide");</script>';
  }else{

  		if (isset($_GET["idSelect"])) {
			$client_bdd = new Client_bdd($_GET["idSelect"]);
		} else {
			$client_bdd = new Client_bdd($_SESSION['identifiant']);
		}	
		$client_bdd->ModifierClient($_POST['cliNum'],$_POST["cliNom"],$_POST["cliPrenom"],$_POST["cliAdr"],$_POST["cliCP"],$_POST["cliVille"],
  $_POST["cliTelFixe"],$_POST["cliTelMob"]);
  
     echo '<script type="text/javascript">window.setTimeout(window.alert("Client modifié."), 50);</script>';

  }
  
  header('Location: ../index.php'); 
?>