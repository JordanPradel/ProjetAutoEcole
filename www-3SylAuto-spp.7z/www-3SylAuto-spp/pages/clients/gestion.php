<!DOCTYPE html>
<html lang="en">

<?php
	include('../../structure/header.php');
?>
<body>

<div id="wrapper">

    <?php
		include($site_racine . 'structure/navigation/secretaire_navigation.php');
		include_once($site_racine.'bdd/secretaire_bdd.php');
		$secretaire_bdd = new Secretaire_bdd();
    ?>

        <!-- Page Content -->
        <div id='page-wrapper'>
            <div class='container-fluid'>
                <div class='row'>
                    <div class='col-lg-12'>
                        <h1 class='page-header'>Gestion des clients</h1>
                    </div>
					<div>
					<?php
					//<!-- TODO CODE HERE  -->
					echo"
					<a href='".$site_url.$repertoire_pages."clients/ajouter.php' style='margin-left:15px'> <input type='button' value='Ajouter élève'> </a>
					<div class='panel-body'>
                            <div class='dataTable_wrapper'>
                                <table class='table table-striped table-bordered table-hover' id='dataTables-client'>";

							//Get user data
							$dataUser = $secretaire_bdd->getListClients();
							//Display table header
							echo "  <thead>
                                        <tr>
                                            <th>Nom<d/th>
                                            <th>Prénom</th>
                                            <th>Code postal</th>
                                            <th>Ville</th>
                                            <th>Actions</th>
                                        </tr>
                                    </thead>
									 <tbody>";

							//Display each row on the table
							for ($i = 0; $i<sizeof($dataUser) ; $i++) {
								echo "<tr>";

								//TODO refaire les liens des boutons (!Parametre d'éleve personalisé)
								echo "<td>".$dataUser[$i]['cliNom']."</td>"
								     ."<td>".$dataUser[$i]['cliPrenom']."</td>"
									 ."<td>".$dataUser[$i]['cliCP']."</td>"
									 ."<td>".$dataUser[$i]['cliVille']."</td>"
									 ."<td><a href='".$site_url.$repertoire_pages."clients/consulter.php?idSelect=".$dataUser[$i]['cliNum']."'> <input type='button' value='Consulter'> </a>
										   <a href='".$site_url.$repertoire_pages."clients/modifier.php?idSelect=".$dataUser[$i]['cliNum']."'> <input type='button' value='Modifier'> </a>
										   <a href='".$site_url.$repertoire_pages."agendas/lecons_conduite.php?profil=client&idSelect=".$dataUser[$i]['cliNum']."'> <input type='button' value='Agenda'> </a></td>"
								     ."</tr>";
							}
							echo "</tbody>";

							echo"
					        </tbody>
                        </table>
						</div>
                    </div>";
					//<!-- CODE END -->
					?>
					</div>
                    <!-- /.col-lg-12 -->
                </div>
                <!-- /.row -->
            </div>
            <!-- /.container-fluid -->
        </div>
        <!-- /#page-wrapper -->

    </div>
    <!-- /#wrapper -->
	<?php
		//Bibliotheques javascript
		include($site_racine . 'structure/footer.php');
	?>

	    <script>
    $(document).ready(function() {
        $('#dataTables-client').DataTable({
                responsive: true
        });
    });
    </script>


</body>

</html>";
?>
