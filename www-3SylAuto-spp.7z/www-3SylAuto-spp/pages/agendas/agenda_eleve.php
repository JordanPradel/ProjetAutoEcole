<!DOCTYPE html>
<html lang="en">

<?php
include('../../structure/header.php');
?>
<body>

<div id="wrapper">

    <?php
    include($site_racine . 'structure/navigation.php');
    include_once($site_racine . 'bdd/secretaire_bdd.php');
    $secretaire_bdd = new Secretaire_bdd();
    ?>

    <!-- Page Content -->
    <div id='page-wrapper'>
        <div class='container-fluid'>
            <div class='row'>
                <div class='col-lg-12'>
                    <h1 class='page-header'>Gestion de l'agenda de l'élève ......</h1>
                </div>
                <div>
                    <?php
                    include($site_racine . 'calendrier/lecons/gestion.php');
                    ?>
                </div>
                <!-- /.col-lg-12 -->
            </div>
            <!-- /.row -->
        </div>
        <!-- /.container-fluid -->
    </div>
    <!-- /#page-wrapper -->

</div>
<!-- /#wrapper -->
<?php
//Bibliotheques javascript
include($site_racine . 'structure/footer.php');
?>

<script type="text/javascript">
    $blackout = $("<div id='blackout'>").css("display", "none").append('<img src="" alt="Chargement en cours">');
    $(document).ready(function()
    {
        alert("ready!");
        function AjouteLeçonCode(date, heure)
        {
            alert('toto');
            var action = '<?php echo $site_url; ?>pages/lecon_code/modifier.php';

            var data = 'date=' + date + '&heure=' + heure;

            $blackout.fadeIn();

            $.ajax({
                method: "GET", url: action, data: data, dataType: 'json'
            }).done(function(reponse)
            {
                if (reponse.code)
                {

                    //Efface le blackout
                    $blackout.fadeOut(function()
                    {
                        // Suprime le blackout
                        $blackout.remove();
                        alert('Upload réussi.')
                    });

                }
                else
                {
                    //Efface le blackout
                    $blackout.fadeOut(function()
                    {
                        // Suprime le blackout
                        $blackout.remove();
                        alert('Mise en ligne non effectué.')
                    });

                }

            }).error(function()
            {
                alert('Une erreur est survenue pendant la mise à jour.');
            });

        }

    });
</script>


</body>

</html>