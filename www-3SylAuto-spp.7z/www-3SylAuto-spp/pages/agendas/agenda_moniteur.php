<!DOCTYPE html>
<html lang="en">

<?php
include('../../structure/header.php');
?>
<body>

<div id="wrapper">

    <?php
    include($site_racine . 'structure/navigation.php');
    include_once($site_racine . 'bdd/secretaire_bdd.php');
    $secretaire_bdd = new Secretaire_bdd();
    ?>

    <!-- Page Content -->
    <div id='page-wrapper'>
        <div class='container-fluid'>
            <div class='row'>
                <div class='col-lg-12'>
                    <h1 class='page-header'>Gestion de l'agenda du moniteur ......</h1>
                </div>
                <?php
                include($site_racine . 'calendrier/lecons/gestion.php');
                ?>
                <!-- CODE END -->
            </div>
            <!-- /.col-lg-12 -->
        </div>
        <!-- /.row -->
    </div>
    <!-- /.container-fluid -->
</div>
<!-- /#page-wrapper -->

</div>
<!-- /#wrapper -->
<?php
//Bibliotheques javascript
include($site_racine . 'structure/footer.php');
?>

<script src="<?php echo $site_url ?>libraries/d3/d3.js"></script>

<script type="text/javascript">

        function AjouteLeconCode(p_date, p_heure)
        {
            alert('Ajout d\'une lecon  de code');
            var action = '<?php echo $site_url; ?>pages/lecons_code/modifier.php';

            var ISOformat = d3.time.format( "%d/%m/%Y" );
            var date = ISOformat( new Date() );

alert(date);
            var data = 'date=' + date + '&heure=' + p_heure;

            $.ajax({
                method: "POST", url: action, data: data, dataType: 'json'
            }).done(function(reponse)
            {
                console.log(reponse);
                if (reponse.code)
                {
                        alert('Upload réussi.')
                }
                else
                {
                        alert('Mise en ligne non effectué.')

                }

            }).error(function(error)
            {
                console.log(error);

                alert('Une erreur est survenue pendant la mise à jour.');
            });

        }

</script>
</body>

</html>
