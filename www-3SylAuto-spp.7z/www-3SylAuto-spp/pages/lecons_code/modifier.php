<?php
include('../../structure/header.php');

function convertis_date_fr_eng($date_fr)
{
    echo '<pre>fr-eng';var_dump(strpos('/', $date_fr));echo '</pre>';

    if (strpos('/', $date_fr)) {
        $codeDate = explode('/', $date_fr);
        $day = $codeDate[0];
        $month = $codeDate[1];
        $year = $codeDate[2];
        $date_eng = $year . '-' . $month . '-' . $day;

        return $date_eng;
    } else {
        return $date_fr;
    }
}

function convertis_date_eng_fr($date_eng)
{
    if (strpos('-', $date_eng)) {
        $codeDate = explode('-', $date_eng);
        $day = $codeDate[2];
        $month = $codeDate[1];
        $year = $codeDate[0];
        $date_fr = $day . '/' . $month . '/' . $year;

        return $date_fr;
    } else {
        return $date_eng;
    }
}


function convertis_heure_int($heure)
{
    if (strpos(':', $heure)) {
        $int = explode(':', $heure)[0];
        return $int;
    } else {
        return $heure;
    }
}

function convertis_int_heure($heure)
{
    echo '<pre>int-heur';var_dump(strpos(':', $heure));echo '</pre>';
    if (strpos(':', $heure)) {
        return $heure;
    } else {
        if ($heure < 10) {
            $heure = '0' . $heure;
        }
        $heure = $heure . ':00:00';

        return $heure;
    }
}


?>
<!-- Custom Fonts -->
<link href="<?php echo $site_url ?>libraries/bootstrap-datepicker/css/bootstrap-datepicker.css" rel="stylesheet" type="text/css">

<body>

<div id="wrapper">

    <?php
    include($site_racine . 'structure/navigation.php');
    ?>
    <!-- Page Content -->
    <div id="page-wrapper">

        <!-- ICI Commence le corps de la page -->
        <div class="container-fluid">
            <div class="row">
                <div class="col-lg-12">
                    <h1 class="page-header">Modifier une leçon</h1>
                    <?php
                    include($site_racine . 'bdd/Lecon_code_bdd.php');
                    include($site_racine . 'libraries/views.php');
                    display_alert();

                    $champs = array(
                        'codeNum'   => null,
                        'codeDate'  => null,
                        'codeHeure' => null,
                    );

                    $lecon_code = new Lecon_code_bdd();

                    //Si la post est passé, les valeurs de post vont dans les champs
                    echo '<pre>';
                    var_dump($_POST, $_GET);
                    echo '</pre>';
                    if (isset($_POST) && !empty($_POST)) {

                        $champs = array_merge($champs, $_POST);

                        //Si c'est une mis a jour d'une leçon existante
                        if ((isset($_POST['codeNum']) && !empty($_POST['codeNum']))) {

                            if (isset($champs['codeDate'])) {
                                $champs['codeDate'] = convertis_date_fr_eng($champs['codeDate']);

                            }
                            if (isset($champs['codeHeure'])) {
                                $champs['codeHeure'] = convertis_int_heure($champs['codeHeure']);
                            }

                            //Modification de la leçon de code correspondante
                            if ($data = $lecon_code->modifier(array('codeNum' => $_POST['codeNum']), $champs)) {
                                //Mis a jour réussis
                                $champs = $data[0];

                                if (isset($champs['codeDate'])) {
                                    $champs['codeDate'] = convertis_date_eng_fr($champs['codeDate']);

                                }
                                if (isset($champs['codeHeure'])) {
                                    $champs['codeHeure'] = convertis_heure_int($champs['codeHeure']);
                                }

                            } else {
                                //Mis a jour raté
                                $redirect = $site_url . 'pages/lecons_code/ajouter.php';
                                $_SESSION['errors'] = 'Saisie incorrect 1';
                                echo '<meta http-equiv="refresh" content="0;URL=' . $redirect . '"> ';
                            }
                        } else {
                            if (isset($champs['codeDate'])) {
                                $champs['codeDate'] = convertis_date_fr_eng($champs['codeDate']);

                            }
                            if (isset($champs['codeHeure'])) {
                                $champs['codeHeure'] = convertis_int_heure($champs['codeHeure']);
                            }

                            echo '<pre>';
                            var_dump($champs);
                            echo '</pre>';
                            //Ajout d'une nouvelle leçon de code
                            $data = $lecon_code->ajouter($champs);

                            if ($data != false) {
                                //Création réussis
                                $champs = $data[0];

                                if (isset($champs['codeDate'])) {
                                    $champs['codeDate'] = convertis_date_eng_fr($champs['codeDate']);

                                }
                                if (isset($champs['codeHeure'])) {
                                    $champs['codeHeure'] = convertis_heure_int($champs['codeHeure']);
                                }


                            } else {
                                //Création raté
                                //Mis a jour raté
                                $redirect = $site_url . 'pages/lecons_code/ajouter.php';
                                $_SESSION['errors'] = 'Saisie incorrect 2 ';
                                echo '<meta http-equiv="refresh" content="0;URL=' . $redirect . '"> ';
                            }
                        }
                    } else {
                        //Selection de la leçon de code par get
                        if ((isset($_GET['codeNum']) && !empty($_GET['codeNum']))) {

                            //Modification de la leçon de code correspondante
                            if ($data = $lecon_code->chercher(array('codeNum' => $_GET['codeNum']))) {
                                $champs = $data[0];

                                if (isset($champs['codeDate'])) {
                                    $champs['codeDate'] = convertis_date_eng_fr($champs['codeDate']);

                                }
                                if (isset($champs['codeHeure'])) {
                                    $champs['codeHeure'] = convertis_heure_int($champs['codeHeure']);
                                }
                            }

                        } else {
                            //Mis a jour raté
                            $redirect = $site_url . 'pages/lecons_code/ajouter.php';
                            $_SESSION['errors'] = 'Mis à jour échoué ' . json_encode($_GET) . json_encode($_POST);
                            echo '<meta http-equiv="refresh" content="0;URL=' . $redirect . '"> ';
                        }
                    }
                    ?>
                    <form action="modifier.php" method="post">

                        <div class="form-group" id="sandbox-container">
                            <label>La date de la leçon </label>
                            <input class="form-control" id="codeDate" placeholder="18/05/2016" name="codeDate"
                                   value="<?php echo $champs['codeDate']; ?>">
                        </div>
                        <div class="form-group">
                            <label>L'heure de la leçon</label>
                            <input type="number" class="form-control" id="codeHeure" placeholder="12h" name="codeHeure"
                                   value="<?php echo $champs['codeHeure']; ?>">
                        </div>
                        <input type="hidden" id="codeNum" name="codeNum" value="<?php echo $champs['codeNum'] ?>"/>

                        <button type="submit" class="btn btn-default">Submit Button</button>
                    </form>

                </div>
                <!-- /.col-lg-12 -->
            </div>
            <!-- /.row -->
        </div>
        <!-- /.container-fluid -->

        <!-- ICI Finit le corps de la page -->
    </div>
    <!-- /#page-wrapper -->

</div>
<!-- /#wrapper -->


<?php
//Bibliotheques javascript
include($site_racine . 'structure/footer.php');
?>
<!-- ICI Commence les includes JS spécifiques à la page de la page -->

<script src="<?php echo $site_url ?>libraries/bootstrap-datepicker/js/bootstrap-datepicker.js"></script>
<script type="text/javascript">
    $('#sandbox-container input').datepicker({
        language: "fr", format: "dd/mm/yyyy", todayBtn: "linked",
    });
</script>

<!-- ICI Finissent les includes JS spécifiques à la page de la page -->
</body>

</html>