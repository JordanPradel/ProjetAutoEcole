<?php
include('../../structure/header.php');
?>
<!-- Custom Fonts -->
<link href="<?php echo $site_url ?>libraries/bootstrap-datepicker/css/bootstrap-datepicker.css" rel="stylesheet" type="text/css">

<body>

<div id="wrapper">

    <?php
    include($site_racine . 'structure/navigation.php');
    ?>
    <!-- Page Content -->
    <div id="page-wrapper">

        <!-- ICI Commence le corps de la page -->
        <div class="container-fluid">
            <div class="row">
                <div class="col-lg-12">
                    <h1 class="page-header">Ajouter une leçon de code</h1>
                    <?php
                    include($site_racine . 'libraries/views.php');
                    display_alert( array(
                        'errors' => isset($_SESSION['errors']) ? array(
                            $_SESSION['errors'],
                        ):array(),
                    )
                    );
                    unset($_SESSION['errors']);
                    $champs = array(
                        'codeNum'   => null,
                        'codeDate'  => null,
                        'codeHeure' => null,
                    );

                    ?>
                    <form action="modifier.php" method="post">
                        <div class="form-group" id="sandbox-container">
                            <label>La date de la leçon </label>
                            <input class="form-control" id="codeDate" placeholder="<?php echo date('d/h/Y'); ?>" name="codeDate"
                                   value="<?php echo $champs['codeDate']; ?>">
                        </div>
                        <div class="form-group">
                            <label>L'heure de la leçon</label>
                            <input type="number" class="form-control" id="codeHeure" placeholder="<?php date('h'); ?>" name="codeHeure"
                                   value="<?php echo $champs['codeHeure'];
                                   ?>">
                        </div>
                        <button type="submit" class="btn btn-default">Submit Button</button>
                    </form>

                </div>
                <!-- /.col-lg-12 -->
            </div>
            <!-- /.row -->
        </div>
        <!-- /.container-fluid -->

        <!-- ICI Finit le corps de la page -->
    </div>
    <!-- /#page-wrapper -->

</div>
<!-- /#wrapper -->


<?php
//Bibliotheques javascript
include($site_racine . 'structure/footer.php');
?>
<!-- ICI Commence les includes JS spécifiques à la page de la page -->
<script src="<?php echo $site_url ?>libraries/bootstrap-datepicker/js/bootstrap-datepicker.js"></script>
<script type="text/javascript">
    $('#sandbox-container input').datepicker({
        language: "fr", format: "dd/mm/yyyy", todayBtn: "linked",
    });
</script>
<!-- ICI Finissent les includes JS spécifiques à la page de la page -->
</body>

</html>