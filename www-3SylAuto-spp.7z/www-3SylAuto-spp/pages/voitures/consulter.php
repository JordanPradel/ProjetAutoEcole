<?php
include('../../structure/header.php');
?>
<body>

<div id="wrapper">

    <?php
    include($site_racine . 'structure/navigation.php');
    ?>
    <!-- Page Content -->
    <div id="page-wrapper">

        <!-- ICI Commence le corps de la page -->
        <div class="container-fluid">
            <div class="row">
                <div class="col-lg-12">
                    <h1 class="page-header">Modifier la voiture</h1>
                    <?php
                    include($site_racine .'bdd/Voiture_bdd.php');
                    include($site_racine .'bdd/Modele_bdd.php');
                    include($site_racine .'bdd/Marque_bdd.php');
                    $champs = array(
                        'voitNum'     => null,
                        'voitImmat'   => null,
                        'voitKm'   => null,
                        'modeleNum' => null,
                    );
                    $voiture = new Voiture_bdd();
                    $model = new Modele_bdd();
                    $marque = new Marque_bdd();

                    $tous_les_modeles = $model->tous();

                    //Si la post est passé, les valeurs de post vont dans les champs
                    if (isset($_POST)  && !empty($_POST)) {
                        $champs = array_merge($champs, $_POST);

                        if((isset($_POST['voitNum']) && !empty($_POST['voitNum']))) {

                            //                            echo '<pre>Mod : champs ';var_dump($champs);echo '</pre>';
                            //Modification de la voiture correspondante
                            if ($data = $voiture->modifier(array('voitNum' =>$champs['voitNum']), $champs)) {
                                //Mis a jour réussis
                                $champs = $data[0];
                            }else{
                                //Mis a jour raté
                                $redirect = 'Location: ' . $GLOBALS['site_url'] . 'pages/voitures/ajouter.php';
                                header($redirect, true);
                            }
                        }else{
                            //Ajout d'une nouvelle voiture
                            $data = $voiture->ajouter($champs);
                            //                            echo '<pre>Ajout : champs ';var_dump($champs, $data);echo '</pre>';

                            if ($data !=  false) {
                                //Création réussis
                                $champs = $data[0];
                            }else{
                                //Création raté
                                //Mis a jour raté
                                $redirect = 'Location: ' . $GLOBALS['site_url'] . 'pages/voitures/ajouter.php';
                                header($redirect, true);
                            }
                        }
                    }else{
                        //Selection de la voiture par get
                        if((isset($_GET['voitNum']) && !empty($_GET['voitNum']))) {

                            //Modification de la voiture correspondante
                            if ($data = $voiture->chercher(array('voitNum' => $_GET['voitNum']))) {
                                $champs = $data[0];
                            }

                        }else {
                            //Mis a jour raté
                            $redirect = 'Location: ' . $GLOBALS['site_url'] . 'pages/voitures/ajouter.php';
                            header($redirect, true);
                        }
                    }
                    ?>

                    <form action="modifier.php" method="post">
                        <div class="form-group">
                            <label>L'immatriculation de la voiture</label>
                            <input class="form-control" id="voitImmat" name="voitImmat" value="<?php echo $champs['voitImmat']?>" >
                        </div>
                        <div class="form-group">
                            <label>Le kilométrage de la voiture</label>
                            <input type="number" class="form-control form-control" id="voitKm" name="voitKm" value="<?php echo $champs['voitKm']?>">
                        </div>
                        <div class="form-group">
                            <label>Le model de voiture</label>
                            <select class="form-control" id="modeleNum" name="modeleNum" >
                                <?php foreach ($tous_les_modeles as $model) {
                                    $cette_marque = $marque->chercher(array('marqueNum' => $model['marqueNum']));
                                    $cette_marque = $cette_marque[0];
                                    $cette_marque['marqueNom'];
                                    if ($model['modeleNum'] == $champs['modeleNum']) {
                                        $selected = ' selected="true" ';
                                    }else{
                                        $selected = ' ';
                                    }
                                    echo '<option value="'.$model['modeleNum']. '" ' . $selected . '> '.$model['modeleNom']. ' - ' .
                                        $cette_marque['marqueNom'] .'</option>';
                                }
                                ?>
                            </select>
                        </div>
                        <input type="hidden" id="voitNum" name="voitNum" value="<?php echo $champs['voitNum']?>" />
                        <button type="submit" class="btn btn-default">Submit Button</button>
                    </form>

                </div>
                <!-- /.col-lg-12 -->
            </div>
            <!-- /.row -->
        </div>
        <!-- /.container-fluid -->

        <!-- ICI Finit le corps de la page -->
    </div>
    <!-- /#page-wrapper -->

</div>
<!-- /#wrapper -->


<?php
//Bibliotheques javascript
include($site_racine . 'structure/footer.php');
?>
<!-- ICI Commence les includes JS spécifiques à la page de la page -->
<!-- Morris Charts JavaScript -->

<!-- ICI Finissent les includes JS spécifiques à la page de la page -->
</body>

</html>