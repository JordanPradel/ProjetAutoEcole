<?php
include('../../structure/header.php');
?>
<body>

<div id="wrapper">

    <?php
    include($site_racine . 'structure/navigation.php');
    ?>
    <!-- Page Content -->
    <div id="page-wrapper">

        <!-- ICI Commence le corps de la page -->
        <div class="container-fluid">
            <div class="row">
                <div class="col-lg-12">
                    <h1 class="page-header">Gestion des voitures</h1>
                    <?php
                    include($site_racine .'bdd/voiture_bdd.php');
                    include($site_racine .'libraries/views.php');
                    $champs = array(
                        'voit Num'     => 'voitNum',
                        'voit Immat'   => 'voitImmat',
                        'voit Km'   => 'voitKm',
                        'modele Num' => 'modeleNum',
                    );

					$voiture = new Voiture_bdd();

					$data = $voiture->tous();


                    create_datatable_v2($champs, $data, 'voitures', 'voitNum', 'voiture', $site_url)
                    ?>

                </div>
                <!-- /.col-lg-12 -->
            </div>
            <!-- /.row -->
        </div>
        <!-- /.container-fluid -->

        <!-- ICI Finit le corps de la page -->
    </div>
    <!-- /#page-wrapper -->

</div>
<!-- /#wrapper -->


<?php
//Bibliotheques javascript
include($site_racine . 'structure/footer.php');
?>


<!-- DataTables JavaScript -->
<script src="<?php echo $site_url; ?>bower_components/datatables/media/js/jquery.dataTables.min.js"></script>
<script src="<?php echo $site_url; ?>bower_components/datatables-plugins/integration/bootstrap/3/dataTables.bootstrap.min.js"></script>

<!-- ICI Commence les includes JS spécifiques à la page de la page -->
<!-- Morris Charts JavaScript -->
<script>
    $(document).ready(function() {
        $('#dataTable').DataTable({
            responsive: true
        });
    });
</script>

<!-- ICI Finissent les includes JS spécifiques à la page de la page -->
</body>

</html>