<?php
include('../../structure/header.php');
?>
<body>

<div id="wrapper">

	<?php
		include($site_racine . 'structure/navigation.php');
		include_once($site_racine.'bdd/eleve_bdd.php');
		include_once($site_racine.'bdd/client_bdd.php');
		include_once($site_racine.'bdd/moniteur_bdd.php');

		if (isset($_GET["idSelect"])) {
			$moniteur_bdd = new Moniteur_bdd($_GET["idSelect"]);
		} else {
			$moniteur_bdd = new Moniteur_bdd($_SESSION['identifiant']);
		}
		$informations_moniteur = $moniteur_bdd->getInformations();

		$liste_eleves = $moniteur_bdd->getListeEleves();

    ?>

    <!-- Page Content -->
    <div id="page-wrapper">

        <!-- ICI Commence le corps de la page -->
        <div class="container-fluid">
            <div class="row">
                <div class="col-lg-12">
                    <h1 class="page-header">Modification moniteur</h1>
					<h3 class="page-header">Informations du moniteur</h3>
					<form action="<?php echo $site_url.$repertoire_pages; ?>moniteurs/modifier.php" method="post">
						<div class="form-group">
							<label for="disabledSelect">Nom</label>
							<input class="form-control" id="nom" type="text" value="<?php echo $informations_moniteur['moniNom']; ?>">
						</div>
						<div class="form-group">
							<label for="disabledSelect">Prénom</label>
							<input class="form-control" id="prenom" type="text" value="<?php echo $informations_moniteur['moniPrenom']; ?>">
						</div>
						<div class="form-group">
							<label for="disabledSelect">Adresse</label>
							<input class="form-control" id="adresse" type="text" value="<?php echo $informations_moniteur['moniAdr']; ?>">
						</div>
						<div class="form-group">
							<label for="disabledSelect">Code postal</label>
							<input class="form-control" id="cp" type="text" value="<?php echo $informations_moniteur['moniCP']; ?>">
						</div>
						<div class="form-group">
							<label for="disabledSelect">Ville</label>
							<input class="form-control" id="ville" type="text" value="<?php echo $informations_moniteur['moniVille']; ?>">
						</div>
						<div class="form-group">
							<label for="disabledSelect">Téléphone fixe</label>
							<input class="form-control" id="telfixe" type="text" value="<?php echo $informations_moniteur['moniTelFixe']; ?>">
						</div>
						<div class="form-group">
							<label for="disabledSelect">Téléphone mobile</label>
							<input class="form-control" id="telmob" type="text" value="<?php echo $informations_moniteur['moniTelMob']; ?>">
						</div>
					</form>

					<div>
					<h3 class="page-header">Liste des élèves du moniteur</h3>
					<?php
					//<!-- TODO CODE HERE  -->
					echo"
					<div class='panel-body'>
                            <div class='dataTable_wrapper'>
                                <table class='table table-striped table-bordered table-hover' id='dataTables-client'>";


							//Display table header
							echo "  <thead>
                                        <tr>
                                            <th>Nom<d/th>
                                            <th>Prénom</th>
											<th>Adresse</th>
                                            <th>Code postal</th>
                                            <th>Ville</th>
                                            <th>Date de naissance</th>
											<th>Tél fixe</th>
											<th>Tél mobile</th>
											<th>Tickets</th>
											<th>Moniteur</th>
											<th>Formule</th>
                                        </tr>
                                    </thead>
									 <tbody>";

							//Display each row on the table
							for ($i = 0; $i<sizeof($liste_eleves) ; $i++) {
								$client_bdd = new Client_bdd($liste_eleves[$i]["cliNum"]);
								$client = "test";
								echo "<tr>";

								//TODO refaire les liens des boutons (!Parametre d'éleve personalisé)
								echo "<td>".$liste_eleves[$i]['eleveNom']."</td>"
								     ."<td>".$liste_eleves[$i]['elevePrenom']."</td>"
									 ."<td>".$liste_eleves[$i]['eleveAdr']."</td>"
									 ."<td>".$liste_eleves[$i]['eleveCP']."</td>"
									 ."<td>".$liste_eleves[$i]['eleveVille']."</td>"
									 ."<td>".$liste_eleves[$i]['eleveNaiss']."</td>"
									 ."<td>".$liste_eleves[$i]['eleveTelFixe']."</td>"
									 ."<td>".$liste_eleves[$i]['eleveTelMob']."</td>"
									 ."<td>".$liste_eleves[$i]['eleveNbTickets']."</td>"
									 ."<td>".$client."</td>"
									 ."<td>".$liste_eleves[$i]['formNum']."</td>"
								     ."</tr>";
							}
							echo "</tbody>";

							echo"
					        </tbody>
                        </table>
						</div>
                    </div>";
					//<!-- CODE END -->
					?>
					</div>

                </div>
                <!-- /.col-lg-12 -->
            </div>
            <!-- /.row -->
        </div>
        <!-- /.container-fluid -->

        <!-- ICI Finit le corps de la page -->
    </div>
    <!-- /#page-wrapper -->

</div>
<!-- /#wrapper -->


<?php
//Bibliotheques javascript
include($site_racine . 'structure/footer.php');
?>
<!-- ICI Commence les includes JS spécifiques à la page de la page -->
<!-- Morris Charts JavaScript -->
<script src="../bower_components/raphael/raphael-min.js"></script>
<script src="../bower_components/morrisjs/morris.min.js"></script>
<script src="../js/morris-data.js"></script>


<!-- ICI Finissent les includes JS spécifiques à la page de la page -->
</body>

</html>