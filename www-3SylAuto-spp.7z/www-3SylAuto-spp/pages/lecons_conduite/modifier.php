<?php
include('../../structure/header.php');
?>
<!-- Custom Fonts -->
<link href="<?php echo $site_url ?>libraries/bootstrap-datepicker/css/bootstrap-datepicker.css" rel="stylesheet" type="text/css">

<body>

<div id="wrapper">

    <?php
    include($site_racine . 'structure/navigation.php');
    ?>
    <!-- Page Content -->
    <div id="page-wrapper">

        <!-- ICI Commence le corps de la page -->
        <div class="container-fluid">
            <div class="row">
                <div class="col-lg-12">
                    <h1 class="page-header">Ajouter une leçon</h1>
                    <?php

                    include($site_racine . 'bdd/Lecon_conduite_bdd.php');
                    include($site_racine . 'bdd/Moniteur_bdd.php');
                    include($site_racine . 'bdd/Eleve_bdd.php');
                    $champs = array(
                        'leconNum'   => null,
                        'leconDate'  => null,
                        'leconHeure' => null,
                        'eleveNum'   => null,
                        'moniNum'    => null,
                    );


                    $lecon_conduite = new Lecon_conduite_bdd();
                    $moniteur = new Moniteur_bdd(0);
                    $eleve = new Eleve_bdd(0);

                    $tous_les_eleves = $eleve->tous();
                    $tous_les_moniteurs = $moniteur->tous();

                    //Si la post est passé, les valeurs de post vont dans les champs
                    if (isset($_GET) && !empty($_GET)) {
                        $champs = array_intersect_key($champs, $_GET);

                        //Si c'est une mis a jour d'une leçon existante
                        if ((isset($_GET['leconNum']) && !empty($_GET['leconNum']))) {

                            //Modification de la voiture correspondante
                            if ($data = $lecon_conduite->modifier(array('leconNum' => $_GET['leconNum']), $champs)) {
                                //Mis a jour réussis
                                $champs = $data[0];
                            } else {
                                //Mis a jour raté
                                $redirect = 'Location: ' . $site_url . 'pages/lecon_conduite/ajouter.php';
                                header($redirect, true);
                            }
                        } else {
                            //Ajout d'une nouvelle voiture
                            $data = $lecon_conduite->ajouter($champs);

                            if ($data != false) {
                                //Création réussis
                                $champs = $data[0];
                            } else {
                                //Création raté
                                //Mis a jour raté
                                $redirect = 'Location: ' . $site_url . 'pages/lecon_conduite/ajouter.php';
                                header($redirect, true);
                            }
                        }
                    } else {
                        //Selection de la voiture par get
                        if ((isset($_GET['leconNum']) && !empty($_GET['leconNum']))) {

                            //Modification de la voiture correspondante
                            if ($data = $lecon_conduite->chercher(array('leconNum' => $_GET['leconNum']))) {
                                $champs = $data[0];
                            }

                        } else {
                            //Mis a jour raté
                            $redirect = 'Location: ' . $site_url . 'pages/lecon_conduite/ajouter.php';
                            header($redirect, true);
                        }
                    }
                    ?>
                    <form action="modifier.php" method="get">

                    <div class="form-group" id="sandbox-container">
                        <label>La date de la leçon </label>
                        <input class="form-control" id="leconDate" placeholder="18/05/2016" value="<?php echo $champs['leconDate']; ?>">
                    </div>
                    <div class="form-group">
                        <label>L'heure de la leçon</label>
                        <input class="form-control" id="leconHeure" placeholder="12h" value="<?php echo $champs['leconHeure']; ?>">
                    </div>
                    <div class="form-group">
                        <label>Le nom de l'eleve </label>
                        <select class="form-control" id="eleveNum">
                            <?php
                            foreach ($tous_les_eleves as $un_eleve) {

                                if ($un_eleve['eleveNum'] == $champs['eleveNum']) {
                                    $selected = ' selected="true" ';
                                } else {
                                    $selected = ' ';
                                }
                                echo '<option value="' . $un_eleve['eleveNum'] . '" ' . $selected . '> ' . $un_eleve['eleveNom'] . ' ' .
                                    $un_eleve['elevePrenom'] . ' </option>';
                            }
                            ?>
                        </select>
                    </div>
                    <div class="form-group">
                        <label>Le nom du moniteur</label>
                        <?php
                        ?>
                        <select class="form-control" id="moniNum">
                            <?php
                            foreach ($tous_les_moniteurs as $un_moniteur) {
                                if ($un_moniteur['moniNum'] == $champs['moniNum']) {
                                    $selected = ' selected="true" ';
                                } else {
                                    $selected = ' ';
                                }
                                echo '<option value="' . $un_moniteur['moniNum'] . '" ' . $selected . '> ' . $un_moniteur['moniNom'] . ' ' .
                                    $un_moniteur['moniPrenom'] . ' </option>';
                            }
                            ?>
                        </select>
                    </div>
                    <input type="hidden" id="leconNum" name="leconNum" value="<?php echo $champs['leconNum']?>" />

                    <button type="submit" class="btn btn-default">Submit Button</button>
                    </form>


                </div>
                <!-- /.col-lg-12 -->
            </div>
            <!-- /.row -->
        </div>
        <!-- /.container-fluid -->

        <!-- ICI Finit le corps de la page -->
    </div>
    <!-- /#page-wrapper -->

</div>
<!-- /#wrapper -->


<?php
//Bibliotheques javascript
include($site_racine . 'structure/footer.php');
?>
<!-- ICI Commence les includes JS spécifiques à la page de la page -->

<script src="<?php echo $site_url ?>libraries/bootstrap-datepicker/js/bootstrap-datepicker.js"></script>
<script type="text/javascript">
    $('#sandbox-container input').datepicker({
        language: "fr",
        format: "dd/mm/yyyy",
        todayBtn: "linked",
    });
</script>

<!-- ICI Finissent les includes JS spécifiques à la page de la page -->
</body>

</html>