<?php
$not_connected = true;
include('../../structure/header.php');
?>
<?php
	include_once($site_racine . '/bdd/utilisateur_bdd.php');
	$utilisateur_bdd = new Utilisateur_bdd();
?>

<body>

    <div class="container">
        <div class="row">
            <div class="col-md-4 col-md-offset-4">
                <div class="login-panel panel panel-default">
                    <div class="panel-heading">
                        <h3 class="panel-title">Veuillez renseigner vos identifiants</h3>
                    </div>
                    <div class="panel-body">
                        <form role="form" action = "connexion.php" method = "post">
                            <fieldset>
                                <div class="form-group">
                                    <input class="form-control" placeholder="Identifiant" name="login" type="login" autofocus>
                                </div>
                                <div class="form-group">
                                    <input class="form-control" placeholder="Mot de passe" name="mdp" type="mdp" value="">
                                </div>
                                <div class="checkbox">
                                    <label>
                                        <input name="remember" type="checkbox" value="Remember Me">Mémoriser
                                    </label>
                                </div>
                                <!-- Change this to a button or input when using this as a form -->
                                <input type="submit" class="btn btn-lg btn-success btn-block" name="Connexion" value="Connexion"/></br>
                            </fieldset>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>

	<?php
		/* Test si passé par page d'accueil */
		if (isset($_POST['login']) && isset($_POST['mdp'])) {
			$utilisateur_bdd->connexion($_POST['login'], $_POST['mdp']);
		}
	?>
<?php
//Bibliotheques javascript
include($site_racine . 'structure/footer.php');
?>
<!-- ICI Commence les includes JS spécifiques à la page de la page -->

<!-- ICI Finissent les includes JS spécifiques à la page de la page -->
</body>

</html>
