<?php /** @author: Colin Peremarty */
var_dump($_SESSION);die("aze");
session_destroy();
//Url du site
$site_url = 'http://' . $_SERVER['HTTP_HOST'] . '/www-3SylAuto-spp/';

//Emplacement de la racine du site
$site_racine = $_SERVER['DOCUMENT_ROOT'] . 'www-3SylAuto-spp/';
$base = explode('?', $_SERVER['REQUEST_URI']);
$file = explode('/', $base[0]);
$file = $file[sizeof($file) - 1];

$repertoire_pages = 'pages/';
session_destroy();
//Redirection vers la page d'accueil
$redirect ='Location: ' . $site_url . 'pages/index.php';
header($redirect, true);
die();
