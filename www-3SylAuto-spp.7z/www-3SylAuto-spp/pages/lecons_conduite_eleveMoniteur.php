<!DOCTYPE html>
<html lang="en">

<?php
	include('../structure/header.php');
?>
<body>

<div id="wrapper">

    <?php
		include($site_racine . 'structure/navigation.php');
    ?>
        <!-- Page Content -->
        <div id="page-wrapper">

					<!-- ICI Commence le corps de la page -->
            <div class="container-fluid">
                <div class="row">
                    <div class="col-lg-12">
                        <h1 class="page-header">Leçons de conduite</h1>
						<?php
							include($site_racine . 'calendrier/lecons_conduite_calendrier.php');
						?>
                    </div>
                    <!-- /.col-lg-12 -->
                </div>
                <!-- /.row -->
            </div>
            <!-- /.container-fluid -->

					<!-- ICI Finit le corps de la page -->
        </div>
        <!-- /#page-wrapper -->

    </div>
    <!-- /#wrapper -->


<?php
	//Bibliotheques javascript
	include($site_racine . 'structure/footer.php');
?>
<!-- ICI Commence les includes JS spécifiques à la page de la page -->
<!-- ICI Finissent les includes JS spécifiques à la page de la page -->
</body>

</html>