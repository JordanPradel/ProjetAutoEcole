<?php
include('../../structure/header.php');
?>
    <!-- Custom Fonts -->
    <link href="<?php echo $site_url ?>libraries/bootstrap-datepicker/css/bootstrap-datepicker.css" rel="stylesheet" type="text/css">
	
<body>

<div id="wrapper">

    <?php
		include($site_racine . 'structure/navigation/secretaire_navigation.php');
		include_once($site_racine.'bdd/eleve_bdd.php');
		include_once($site_racine.'bdd/client_bdd.php');
		include_once($site_racine.'bdd/moniteur_bdd.php');
		include_once($site_racine.'bdd/formule_bdd.php');
		if (isset($_GET["idSelect"])) {
			$eleve_bdd = new Eleve_bdd($_GET["idSelect"]);
			$Client_bdd = new Client_bdd($_GET["idSelect"]);
			$moniteur_bdd = new Moniteur_bdd($_GET["idSelect"]);
			$formule_bdd = new Formule_bdd();
		} else {
			$eleve_bdd = new Eleve_bdd($_GET["identifiant"]);
			$Client_bdd = new Client_bdd($_SESSION['identifiant']);
			$moniteur_bdd = new Moniteur_bdd($_GET["identifiant"]);
			$formule_bdd = new Formule_bdd();
		}
		
		$informations_eleve = $eleve_bdd->getInformations();
		$listeClient = $Client_bdd->getAllClient();
		$listeMoniteur = $moniteur_bdd->getAllMoniteur();
		$listeFormule = $formule_bdd->getAllFormule();
		
		$moniteur_bdd = new Moniteur_bdd($informations_eleve["moniNum"]);
		$client_bdd = new Client_bdd($informations_eleve["cliNum"]);
		
		$client = $client_bdd->getNomClient();
		$moniteur = $moniteur_bdd->getNomMoniteur();
		
    ?>
    <!-- Page Content -->
    <div id="page-wrapper">

        <!-- ICI Commence le corps de la page -->
        <div class="container-fluid">
            <div class="row">
                <div class="col-lg-12">
                    <h1 class="page-header">Modification élève</h1>
					<form action="<?php echo $site_url.$repertoire_pages; ?>eleves/modifierAction.php" method="post">
						<div class="form-group">
							<label for="disabledSelect">Nom</label>
							<input class="form-control" name="eleveNom" required="required" type="text" value="<?php echo $informations_eleve['eleveNom']; ?>">
						</div>
						<div class="form-group">
							<label for="disabledSelect">Prénom</label>
							<input class="form-control" name="elevePrenom" required="required" type="text" value="<?php echo $informations_eleve['elevePrenom']; ?>">
						</div>
						<div class="form-group">
							<label for="disabledSelect">Adresse</label>
							<input class="form-control" name="eleveAdr" required="required" type="text" value="<?php echo $informations_eleve['eleveAdr']; ?>">
						</div>
						<div class="form-group">
							<label for="disabledSelect">Code postal</label>
							<input class="form-control" name="eleveCP" required="required" type="text" value="<?php echo $informations_eleve['eleveCP']; ?>">
						</div>
						<div class="form-group">
							<label for="disabledSelect">Ville</label>
							<input class="form-control" name="eleveVille" required="required" type="text" value="<?php echo $informations_eleve['eleveVille']; ?>">
						</div>
						<div class="form-group" id="sandbox-container">
							<label for="disabledSelect" >Date de naissance</label>
							<input class="form-control" name="eleveNaiss" required="required"  value="<?php echo $informations_eleve['eleveNaiss']; ?>">
						</div>
						<div class="form-group">
							<label for="disabledSelect">Téléphone fixe</label>
							<input class="form-control" name="eleveTelFixe" required="required" type="text" value="<?php echo $informations_eleve['eleveTelFixe']; ?>">
						</div>
						<div class="form-group">
							<label for="disabledSelect">Téléphone mobile</label>
							<input class="form-control" name="eleveTelMob" required="required" type="text" value="<?php echo $informations_eleve['eleveTelMob']; ?>">
						</div>

						<input class="form-control" name="eleveNbTickets" type="hidden" value="<?php echo $informations_eleve['eleveNbTickets']; ?>">
						
						<div class="form-group">
							<label for="disabledSelect">Formule</label><br>
							<SELECT name="formNum" size="1" >
							<?php
							for($i=0;$i<sizeof($listeFormule);$i++){
								if($listeFormule[$i]['formNum']==$informations_eleve['formNum']){
									echo "<OPTION selected value=".$listeFormule[$i]['formNum'].">Formule ".$listeFormule[$i]['formNum']." => Prix : ".$listeFormule[$i]['formForfait']."€ Nombre de tickets initial : ".
									$listeFormule[$i]['formNbTickets']." Prix unitaire ticket : ".$listeFormule[$i]['formPrixUnitaireTicket']."€";
								}else{
									echo "<OPTION value=".$listeFormule[$i]['formNum'].">Formule ".$listeFormule[$i]['formNum']." => Prix : ".$listeFormule[$i]['formForfait']."€ Nombre de tickets initial : ".
									$listeFormule[$i]['formNbTickets']." Prix unitaire ticket : ".$listeFormule[$i]['formPrixUnitaireTicket']."€";
								}
							}
							?>
							</SELECT>
						</div>
						<div class="form-group">
							<label for="disabledSelect">Nom du client</label><br>
							<SELECT name="cliNum" size="1" >
							<?php
							for($i=0;$i<sizeof($listeClient);$i++){
								if($listeClient[$i]['cliNom']." ".$listeClient[$i]['cliPrenom']==$client){
									echo "<OPTION selected value=".$listeClient[$i]['cliNum'].">".$listeClient[$i]['cliNom']." ".$listeClient[$i]['cliPrenom'];
								}else{
									echo "<OPTION value=".$listeClient[$i]['cliNum'].">".$listeClient[$i]['cliNom']." ".$listeClient[$i]['cliPrenom'];
								}
							}
							
							?>
							</SELECT>
						</div>
						<div class="form-group">
							<label for="disabledSelect">Nom du moniteur</label><br>
							<SELECT name="moniNum" size="1" >
							<?php
							for($i=0;$i<sizeof($listeMoniteur);$i++){
								if($listeMoniteur[$i]['moniNom']." ".$listeMoniteur[$i]['moniPrenom']==$moniteur){
									echo "<OPTION selected value=".$listeMoniteur[$i]['moniNum'].">".$listeMoniteur[$i]['moniNom']." ".$listeMoniteur[$i]['moniPrenom'];
								}else{
									echo "<OPTION value=".$listeMoniteur[$i]['moniNum'].">".$listeMoniteur[$i]['moniNom']." ".$listeMoniteur[$i]['moniPrenom'];
								}
							}
							
							?>
							</SELECT>
						</div>	
						<input class="form-control" name="eleveNum" type="hidden" value="<?php echo $informations_eleve['eleveNum']; ?>">
						<input type="submit" value="Modifier" ></code>
					</form>
                </div>
                <!-- /.col-lg-12 -->
            </div>
            <!-- /.row -->
        </div>
        <!-- /.container-fluid -->

        <!-- ICI Finit le corps de la page -->
    </div>
    <!-- /#page-wrapper -->

</div>
<!-- /#wrapper -->


<?php
//Bibliotheques javascript
include($site_racine . 'structure/footer.php');
?>
<!-- ICI Commence les includes JS spécifiques à la page de la page -->

    <script src="<?php echo $site_url ?>libraries/bootstrap-datepicker/js/bootstrap-datepicker.js"></script>
<script type="text/javascript">
$('#sandbox-container input').datepicker({
    format: "yyyy-mm-dd"
});
</script>


<!-- ICI Finissent les includes JS spécifiques à la page de la page -->
</body>

</html>