<?php      

  include('../../structure/header.php');
  include "../../bdd/Eleve_bdd.php";
  if(!(ISSET($_POST["eleveNom"])&&ISSET($_POST["elevePrenom"])&&ISSET($_POST["eleveAdr"])&&ISSET($_POST["eleveCP"])
		&&ISSET($_POST["eleveVille"])&&ISSET($_POST["eleveNaiss"])&&ISSET($_POST["eleveTelFixe"])&&ISSET($_POST["eleveTelMob"])
		&&ISSET($_POST["eleveNbTickets"])&&ISSET($_POST["cliNum"])&&ISSET($_POST["moniNum"])&&ISSET($_POST["formNum"]))){
	  echo '<script type="text/javascript">window.alert("Erreur : Parametre invalide");</script>';
  }else{

  		if (isset($_GET["idSelect"])) {
			$Eleve_bdd = new Eleve_bdd($_GET["idSelect"]);
		} else {
			$Eleve_bdd = new Eleve_bdd($_SESSION['identifiant']);
		}	
		$Eleve_bdd->AddNewEleve($_POST["eleveNom"],$_POST["elevePrenom"],$_POST["eleveAdr"],$_POST["eleveCP"],$_POST["eleveVille"],
  $_POST["eleveNaiss"],$_POST["eleveTelFixe"],$_POST["eleveTelMob"],$_POST["eleveNbTickets"],$_POST["cliNum"],$_POST["moniNum"],$_POST["formNum"]);
  
     echo '<script type="text/javascript">window.setTimeout(window.alert("Eleve ajoute."), 50);</script>';

  }
  
  header('Location: gestion.php'); 
?>