<?php
include('../../structure/header.php');
?>
<body>

<div id="wrapper">

    <?php
		include($site_racine . 'structure/navigation/secretaire_navigation.php');
		include_once($site_racine.'bdd/eleve_bdd.php');
		include_once($site_racine.'bdd/client_bdd.php');
		include_once($site_racine.'bdd/moniteur_bdd.php');
		if (isset($_GET["idSelect"])) {
			$eleve_bdd = new Eleve_bdd($_GET["idSelect"]);
		} else {
			$eleve_bdd = new Eleve_bdd($_SESSION['identifiant']);
		}
		
		$informations_eleve = $eleve_bdd->getInformations();
		
		$moniteur_bdd = new Moniteur_bdd($informations_eleve["moniNum"]);
		$client_bdd = new Client_bdd($informations_eleve["cliNum"]);
		
		$client = $client_bdd->getNomClient();
		$moniteur = $moniteur_bdd->getNomMoniteur();
		
    ?>
    <!-- Page Content -->
    <div id="page-wrapper">

        <!-- ICI Commence le corps de la page -->
        <div class="container-fluid">
            <div class="row">
                <div class="col-lg-12">
                    <h1 class="page-header">Consultation élève</h1>
					<div class="form-group">
						<label for="disabledSelect">Nom</label>
						<input class="form-control" id="nom" type="text" value="<?php echo $informations_eleve['eleveNom']; ?>" disabled>
					</div>
					<div class="form-group">
						<label for="disabledSelect">Prénom</label>
						<input class="form-control" id="prenom" type="text" value="<?php echo $informations_eleve['elevePrenom']; ?>" disabled>
					</div>
					<div class="form-group">
						<label for="disabledSelect">Adresse</label>
						<input class="form-control" id="adresse" type="text" value="<?php echo $informations_eleve['eleveAdr']; ?>" disabled>
					</div>
					<div class="form-group">
						<label for="disabledSelect">Code postal</label>
						<input class="form-control" id="cp" type="text" value="<?php echo $informations_eleve['eleveCP']; ?>" disabled>
					</div>
					<div class="form-group">
						<label for="disabledSelect">Ville</label>
						<input class="form-control" id="dtnaiss" type="text" value="<?php echo $informations_eleve['eleveVille']; ?>" disabled>
					</div>
					<div class="form-group">
						<label for="disabledSelect">Date de naissance</label>
						<input class="form-control" id="dtnaiss" type="text" value="<?php echo $informations_eleve['eleveNaiss']; ?>" disabled>
					</div>
					<div class="form-group">
						<label for="disabledSelect">Téléphone fixe</label>
						<input class="form-control" id="telfixe" type="text" value="<?php echo $informations_eleve['eleveTelFixe']; ?>" disabled>
					</div>
					<div class="form-group">
						<label for="disabledSelect">Téléphone mobile</label>
						<input class="form-control" id="telmob" type="text" value="<?php echo $informations_eleve['eleveTelMob']; ?>" disabled>
					</div>
					<div class="form-group">
						<label for="disabledSelect">Tickets restants</label>
						<input class="form-control" id="nbtickets" type="text" value="<?php echo $informations_eleve['eleveNbTickets']; ?>" disabled>
					</div>
					<div class="form-group">
						<label for="disabledSelect">Formule</label>
						<input class="form-control" id="formule" type="text" value="<?php echo $informations_eleve['formNum']; ?>" disabled>
					</div>
					<div class="form-group">
						<label for="disabledSelect">Nom du client</label>
						<input class="form-control" id="clinom" type="text" value="<?php echo $client; ?>" disabled>
					</div>
					<div class="form-group">
						<label for="disabledSelect">Nom du moniteur</label>
						<input class="form-control" id="moninom" type="text" value="<?php echo $moniteur; ?>" disabled>
					</div>					
                </div>
                <!-- /.col-lg-12 -->
            </div>
            <!-- /.row -->
        </div>
        <!-- /.container-fluid -->

        <!-- ICI Finit le corps de la page -->
    </div>
    <!-- /#page-wrapper -->

</div>
<!-- /#wrapper -->


<?php
//Bibliotheques javascript
include($site_racine . 'structure/footer.php');
?>
<!-- ICI Commence les includes JS spécifiques à la page de la page -->
<!-- Morris Charts JavaScript -->
<script src="../bower_components/raphael/raphael-min.js"></script>
<script src="../bower_components/morrisjs/morris.min.js"></script>
<script src="../js/morris-data.js"></script>


<!-- ICI Finissent les includes JS spécifiques à la page de la page -->
</body>

</html>