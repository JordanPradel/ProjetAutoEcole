<!DOCTYPE html>
<html lang="en">

<?php
	include('../../structure/header.php');
?>
<body>

<div id="wrapper">

    <?php
		include($site_racine . 'structure/navigation.php');
		include_once($site_racine.'bdd/secretaire_bdd.php');
		$secretaire_bdd = new Secretaire_bdd();
    ?>

	<!-- Page Content -->
	<div id='page-wrapper'>
		<div class='container-fluid'>
			<div class='row'>
				<div class='col-lg-12'>
					<h1 class='page-header'>Gestion des élèves</h1>
				</div>
				<div>
				<?php
				//<!-- TODO CODE HERE  -->
				echo"
				<a href='".$site_url.$repertoire_pages."eleves/ajouter.php' style='margin-left:15px'> <input type='button' value='Ajouter élève'> </a>
				<div class='panel-body'>
						<div class='dataTable_wrapper'>
							<table class='table table-striped table-bordered table-hover' id='dataTables-eleve'>";


						//Get user data
						$dataUser = $secretaire_bdd->getListEleves();
						//Display table header
						echo "  <thead>
									<tr>
										<th>Nom<d/th>
										<th>Prénom</th>
										<th>Nombre de ticket(s)</th>
										<th>Nom Client</th>
										<th>Actions</th>
									</tr>
								</thead>
								 <tbody>";

						//Display each row on the table
						for ($i = 0; $i<sizeof($dataUser) ; $i++) {
							echo "<tr>";

							//TODO refaire les liens des boutons (!Parametre d'éleve personalisé)
							echo "<td>".$dataUser[$i]['eleveNom']."</td>"
								 ."<td>".$dataUser[$i]['elevePrenom']."</td>"
								 ."<td>".$dataUser[$i]['eleveNbTicket']."</td>"
								 ."<td>".$dataUser[$i]['cliNom']."</td>"
								 ."<td><a href='".$site_url.$repertoire_pages."eleves/consulter.php?idSelect=".$dataUser[$i]['eleveNum']."'> <input type='button' value='Consulter'> </a>
									   <a href='".$site_url.$repertoire_pages."eleves/modifier.php?idSelect=".$dataUser[$i]['eleveNum']."'> <input type='button' value='Modifier'> </a>
									   <a href='".$site_url.$repertoire_pages."eleves/facture.php?idSelect=".$dataUser[$i]['eleveNum']."'><input type='button' value='Afficher facture'> </a>
									   <a href='".$site_url.$repertoire_pages."agendas/lecons_conduite.php?profil=eleve&idSelect=".$dataUser[$i]['eleveNum']."'> <input type='button' value='Agenda'> </a>
									   <a href='#'> <input onclick='buy_ticket(".$dataUser[$i]['eleveNum'].")'  type='Button' value='Acheter ticket leçon'/></a>   "
								 ."</tr>";
						}
						echo "</tbody>";
						?>

						</tbody>
					</table>
					</div>
				</div>
				<!-- CODE END -->
				</div>
				<!-- /.col-lg-12 -->
			</div>
			<!-- /.row -->
		</div>
		<!-- /.container-fluid -->
	</div>
	<!-- /#page-wrapper -->

    </div>
    <!-- /#wrapper -->
	<?php
		//Bibliotheques javascript
		include($site_racine . 'structure/footer.php');
	?>

    <!-- jQuery -->
    <script src='../../bower_components/datatables/media/js/jquery.dataTables.min.js'></script>

	
	<script>
	
	function buy_ticket(numEleve)
	{
		var nbTicket = window.prompt("Nombre de ticket à acheter","0");
		if(!isNaN(parseFloat(nbTicket)) && isFinite(nbTicket) && nbTicket>0){
			javascript:document.location.href='AddTicket.php?nbTicket='+nbTicket+'&numEleve='+numEleve;
		}else{
			if(nbTicket!=null){
				alert("Nombre de ticket invalide(doit être une valeur numérique supérieure à 0).")
			}
		}
	}	

    $(document).ready(function() {
        $('#dataTables-eleve').DataTable({
                responsive: true
        });
    });
    </script>


</body>

</html>";
?>
