﻿<?php
include('../../structure/header.php');
?>
<body>

<div id="wrapper">

	<?php
		include($site_racine . 'structure/navigation/secretaire_navigation.php');
		include_once($site_racine.'bdd/eleve_bdd.php');
		include_once($site_racine.'bdd/client_bdd.php');
		include_once($site_racine.'bdd/moniteur_bdd.php');
		
		if (isset($_GET["idSelect"])) {
			$eleve_bdd = new eleve_bdd($_GET["idSelect"]);
		} else {
			$eleve_bdd = new eleve_bdd($_SESSION['identifiant']);
		}	
		$informations_client = $eleve_bdd->getInformations();
		
		$dataEleve = $eleve_bdd->getInformations();
		$dataFacture = $eleve_bdd->getFactureEleve();
    ?>
	
    <!-- Page Content -->
    <div id="page-wrapper">

        <!-- ICI Commence le corps de la page -->
        <div class="container-fluid">
            <div class="row">
                <div class="col-lg-12">
                    <h1 class="page-header">Modification client</h1>

					
					<div>
<?php
					if(!ISSET($_GET['idSelect'])){
						echo "Erreur : paramétre manquant.";
					}else{
						echo"<h1> Facture de l'élève ".$dataEleve['eleveNom']." ".$dataEleve['elevePrenom']."</h1>".					
						"<p> <b>Adresse :</b><br>  ".$dataEleve['eleveAdr']."<br>".$dataEleve['eleveCP']." ".$dataEleve['eleveVille'].
						"<br><br><p> <b>Numéro formule :</b>  ".$dataEleve['formNum'].
						"<br><br><p> <b>Prix Forfaitaire :</b>  ".$dataEleve['formForfait'].
						"<br><br><p> <b>Prix unitaire ticket  :</b>  ".$dataEleve['formPrixUnitaireTicket'].
						
						"<table class='table table-striped table-bordered table-hover'>
							<tr>
								<th>Num Achat</th>
								<th>Date Achat</th> 
								<th>Nombre de ticket Acheté</th> 
								<th>Prix lot</th>";
						$prixTOTAL = $dataEleve['formForfait'];
						for($i=0;$i<sizeof($dataFacture);$i++){
							echo"<tr>".
							    "<td>".($i+1)."</td>".
								"<td>".$dataFacture[$i]['dateAchatTicket']."</td>".
								"<td>".$dataFacture[$i]['nbAchatTicket']."</td>".
								"<td>".$dataFacture[$i]['nbAchatTicket']*$dataEleve['formPrixUnitaireTicket']."€</td>".
								"</tr>";	
							$prixTOTAL+=$dataFacture[$i]['nbAchatTicket']*$dataEleve['formPrixUnitaireTicket'];
						}
						echo "<tr><td><b>Prix total :</b></td><td colspan='3' style='text-align: right;'>".$prixTOTAL."€</td></table>";
					}
					
?>				
				</div>
                </div>
                <!-- /.col-lg-12 -->
            </div>
            <!-- /.row -->
        </div>
        <!-- /.container-fluid -->

        <!-- ICI Finit le corps de la page -->
    </div>
    <!-- /#page-wrapper -->

</div>
<!-- /#wrapper -->


<?php
//Bibliotheques javascript
include($site_racine . 'structure/footer.php');
?>
<!-- ICI Commence les includes JS spécifiques à la page de la page -->
<!-- Morris Charts JavaScript -->
<script src="../bower_components/raphael/raphael-min.js"></script>
<script src="../bower_components/morrisjs/morris.min.js"></script>
<script src="../js/morris-data.js"></script>


<!-- ICI Finissent les includes JS spécifiques à la page de la page -->
</body>

</html>
