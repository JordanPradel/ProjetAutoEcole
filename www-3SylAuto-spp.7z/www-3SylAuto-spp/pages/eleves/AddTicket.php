<?php      

  include('../../structure/header.php');
  include "../../bdd/eleve_bdd.php";
  if(!(ISSET($_GET['nbTicket'])&&ISSET($_GET["numEleve"]))){
	  echo '<script type="text/javascript">window.alert("Erreur : Parametres invalides");</script>';
  }else{

  		if (isset($_GET["idSelect"])) {
			$eleve_bdd = new Eleve_bdd($_GET["idSelect"]);
		} else {
			$eleve_bdd = new Eleve_bdd($_SESSION['identifiant']);
		}	
		$eleve_bdd->addTicket($_GET['numEleve'],$_GET["nbTicket"]);
  
     echo '<script type="text/javascript">window.setTimeout(window.alert("Tickets Ajoutés"), 50);</script>';

  }
  
  header('Location: gestion.php'); 
?>