<!DOCTYPE html>
<html lang="en">

<?php
	include('../../../../structure/header.php');
?>
<body>

<div id="wrapper">

    <?php
		include($site_racine . 'structure/navigation.php');
		include_once($site_racine.'bdd/secretaire_bdd.php');
		$secretaire_bdd = new Secretaire_bdd();
    ?>

	<!-- Page Content -->
	<div id='page-wrapper'>
		<div class='container-fluid'>
			<div class='row'>
				<div class='col-lg-12'>
					<h1 class='page-header'>Gestion de l'agenda de l'élève ......</h1>
				</div>
				<div>
					<?php
						include($site_racine . 'calendrier/lecons/gestion.php');
					?>
				</div>
				<!-- /.col-lg-12 -->
			</div>
			<!-- /.row -->
		</div>
		<!-- /.container-fluid -->
	</div>
	<!-- /#page-wrapper -->

    </div>
    <!-- /#wrapper -->
	<?php
		//Bibliotheques javascript
		include($site_racine . 'structure/footer.php');
	?>

    <!-- jQuery -->
    <script src='<?php echo $site_racine; ?>bower_components/datatables/media/js/jquery.dataTables.min.js'></script>

	<script>
    $(document).ready(function() {
        $('#dataTables-eleve').DataTable({
                responsive: true
        });
    });
    </script>


</body>

</html>";
?>
