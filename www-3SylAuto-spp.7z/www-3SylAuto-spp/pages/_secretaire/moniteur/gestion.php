<!DOCTYPE html>
<html lang="en">

<?php
	include('../../../structure/header.php');
?>
<body>

<div id="wrapper">

    <?php
		include($site_racine . 'structure/navigation.php');
		include_once($site_racine.'bdd/secretaire_bdd.php');
		$secretaire_bdd = new Secretaire_bdd();
    ?>

        <!-- Page Content -->
        <div id='page-wrapper'>
            <div class='container-fluid'>
                <div class='row'>
                    <div class='col-lg-12'>
                        <h1 class='page-header'>Gestion des moniteurs</h1>
                    </div>
					<div>";
					<?php
					//<!-- TODO CODE HERE  -->
					echo"
					<a href='".$site_url.$repertoire_pages."moniteurs/ajouter.php' style='margin-left:15px'> <input type='button' value='Nouveau moniteur'> </a>
					<div class='panel-body'>
                            <div class='dataTable_wrapper'>
                                <table class='table table-striped table-bordered table-hover' id='dataTables-eleve'>";

							//Get user data
							$dataUser = $secretaire_bdd->getListMoniteurs();
							//Display table header
							echo "  <thead>
                                        <tr>
                                            <th>Nom<d/th>
                                            <th>Prénom</th>
                                            <th>Voiture Responsable</th>
                                            <th>Modèle voiture</th>
                                            <th>Actions</th>
                                        </tr>
                                    </thead>
									 <tbody>";

							//Display each row on the table
							for ($i = 0; $i<sizeof($dataUser) ; $i++) {
								echo "<tr>";

								//TODO refaire les liens des boutons (!Parametre d'éleve personalisé)
								echo "<td>".$dataUser[$i]['moniNom']."</td>"
								     ."<td>".$dataUser[$i]['moniPrenom']."</td>"
									 ."<td>".$dataUser[$i]['voitImmat']."</td>"
									 ."<td>".$dataUser[$i]['modeleNom']."</td>"
									 ."<td><a href='".$site_url.$repertoire_pages."moniteurs/consulter.php?idSelect=".$dataUser[$i]['moniNum']."'> <input type='button' value='Consulter'> </a>
										   <a href='".$site_url.$repertoire_pages."moniteurs/modifier.php?idSelect=".$dataUser[$i]['moniNum']."'> <input type='button' value='Modifier'> </a>
										   <a href='".$site_url.$repertoire_pages."agendas/lecons_conduite.php?profil=moniteur&idSelect=".$dataUser[$i]['moniNum']."'> <input type='button' value='Agenda'> </a></td>"
								     ."</tr>";
							}
							echo "</tbody>";
							?>

					        </tbody>
                        </table>
						</div>
                    </div>
					<!-- CODE END -->
					</div>
                    <!-- /.col-lg-12 -->
                </div>
                <!-- /.row -->
            </div>
            <!-- /.container-fluid -->
        </div>
        <!-- /#page-wrapper -->

    </div>
    <!-- /#wrapper -->
	<?php
		//Bibliotheques javascript
		include($site_racine . 'structure/footer.php');
	?>
    <!-- jQuery -->
    <script src='../../bower_components/datatables/media/js/jquery.dataTables.min.js'></script>

	<script>
    $(document).ready(function() {
        $('#dataTables-eleve').DataTable({
                responsive: true
        });
    });
    </script>


</body>

</html>";
?>
