    <style>

        #menu-demo2, #menu-demo2 ul {
            padding: 0;
            margin: 0;
            list-style: none;
            text-align: center;
        }

        #menu-demo2 li {
            position: relative;
            border-radius: 50px 50px 0 0;
        }

        #menu-demo2 ul li {
            display: inherit;
            border-radius: 0;
        }

        #menu-demo2 ul li:last-child {
            border-radius: 0 0 8px 8px;
        }

        #menu-demo2 ul {
            position: absolute;
            z-index: 1000;
            max-height: 0;
            left: 0;
            right: 0;
            overflow: hidden;
            -moz-transition: .8s all .3s;
            -webkit-transition: .8s all .3s;
            transition: .8s all .3s;
        }

        #menu-demo2 li:hover ul {
            background-image: url(plus.png);
            max-height: 15em;
        }

        #menu-demo2 li:last-child {
            background-color: #FFFFFF;
        }

        /* background des liens sous menus */
        #menu-demo2 li:first-child li {
            background: #EFF3FF;
        }

        #menu-demo2 li:nth-child(2) li {
            background: #EFF3FF;
        }

        #menu-demo2 li:nth-child(3) li {
            background: #EFF3FF;
        }

        #menu-demo2 li:last-child li {
            background: #EFF3FF;
        }

        /* background des liens menus et sous menus au survol */
        #menu-demo2 li:first-child:hover, #menu-demo2 li:first-child li:hover {
            background: #FFFFFF;
        }

        #menu-demo2 li:nth-child(2):hover, #menu-demo2 li:nth-child(2) li:hover {
            background: #FFFFFF;
        }

        #menu-demo2 li:nth-child(3):hover, #menu-demo2 li:nth-child(3) li:hover {
            background: #FFFFFF;
        }

        #menu-demo2 li:last-child:hover, #menu-demo2 li:last-child li:hover {
            background: #EFF3FF;
        }

        /* les a href */
        #menu-demo2 a {
            text-decoration: none;
            display: block;
            padding: 8px 32px;
        }

        #menu-demo2 a.texte {
            background-color: #CDF0F0;
            font-size: 1.3em;
        }

        #menu-demo2 a.courant {
            background-color: #87E990;
            font-size: 1.3em;
        }

        #menu-demo2 ul a {
            padding: 8px 0;
        }

        #menu-demo2 li:hover li a {
            color: #000;
            text-transform: inherit;
        }

        #menu-demo2 li:hover a, #menu-demo2 li li:hover a {
            color: #87E990;
        }

        caption {
            margin: auto;
            font-family: Arial, Times, "Times New Roman", serif;
            font-weight: bold;
            font-size: 1.2em;
            color: #EFF3FF;
            margin-bottom: 20px;

        }

        table {
            margin: auto;
            border: 4px outset #EFF3FF;
            border-collapse: collapse;
            width: 100%;
        }

        th {
            background-color: #EFF3FF;
            color: black;
            font-size: 1em;
            font-family: Arial, "Arial Black", Times, "Times New Roman", serif;
            border: 1px;
            text-align: center;
        }

        .heure {
            background-color: #EFF3FF;
            color: black;
            font-size: 1em;
            font-family: Arial, "Arial Black", Times, "Times New Roman", serif;
            text-align: center;
            width: 2%;
        }

        td {
            border: 1px solid black;
            font-family: "Trebuchet MS", "Times", serif;
            font-size: 1em;
            text-align: center;
            padding: 5px;
            width: 14%;
            height: 50px;
        }

        .courant {
            background-color: #87E990;
        }

        .hautgauche {
            border: 1px solid black;
            background-color: #FFFFFF;
            width: 2%;
        }

        jourcourant {
            background-color: #87E990;
            text-decoration: underline;
            font-weight: bold;
            font-size: 1.3em;
        }

        texte {
            display: block;
            background-color: #CDF0F0;
            font-size: 1.3em;
        }

    </style>

<td class="machin">
    <?php
    include_once($site_racine . 'bdd/lecons_bdd.php');
    /* A FAIRE --> Test si l'utilisateur connecté est un élève */
    $liste_lecon_bdd = new Liste_Lecon();

    $liste_lecons = $liste_lecon_bdd->liste_lecons_code();
    ?>


    <?php
    // Définit le fuseau horaire par défaut à utiliser. Disponible depuis PHP 5.1
    date_default_timezone_set('UTC');
    $jour = array("Lundi", "Mardi", "Mercredi", "Jeudi", "Vendredi", "Samedi", "Dimanche");
    $mois = array("", "Janvier", "Février", "Mars", "Avril", "Mai", "Juin", "Juillet", "Août", "Septembre", "Octobre", "Novembre", "Décembre");

    $week = date("W");
    $year = (isset($_GET['year'])) ? $_GET['year'] : date("Y");
    $week = (isset($_GET['week'])) ? $_GET['week'] : Date('W');
    if ($week > 53) {
        $year += 1;
        $week = 1;
    } else if ($week < 1) {
        $year -= 1;
        $week = 53;
    }

    ?>
    <table>
        <caption>
            <?php echo '<a href="' . $_SERVER["PHP_SELF"] . '?week=' . ($week - 1) . '&year=' . $year . '"><<</a>'; // Previous week
            // Affichage de la semaine
            echo '<span style="color: #000000;"> Semaine ' . $week . ' </span>';

            echo '<a href="' . $_SERVER["PHP_SELF"] . '?week=' . ($week + 1) . '&year=' . $year . '">>></a>'; // Next week
            ?>
        </caption>


        <tr>
            <th class="hautgauche"></th>
            <?php
            for ($day = 1; $day <= 7; $day++) {
                $date = strtotime($year . "W" . $week . $day);
                if (date("m", $date) == date('m') && date("Y", $date) == date('Y') && date("d", $date) == date("d")) {
                    echo '<th><jourcourant>' . $jour[$day - 1] . ' ' . date("d", $date) . ' ' . $mois[date("n", $date)] . '</jourcourant></th>';
                } else {
                    echo '<th>' . $jour[$day - 1] . ' ' . date("d", $date) . ' ' . $mois[date("n", $date)] . '</th>';
                }

            }
            ?>
        </tr>

        <?php
        for ($heure = $_SESSION["heure_ouverture"]; $heure <= $_SESSION["heure_fermeture"]; $heure++) {
            echo '<tr>'; // Nouvelle ligne du tableau
            echo '<td class="heure">' . $heure . ':00' . '</td>';

            for ($day = 1; $day <= 7; $day++) {
                $date = strtotime($year . "W" . $week . $day);
                if (date("m", $date) == date("m") && date("Y", $date) == date("Y") && date("d", $date) == date("d")) {
                    $class = 'courant';
                } else {
                    $class = '';
                }
                // Recherche une leçon à cette date
                if ($liste_lecon_bdd->lecon_existe_a_date($liste_lecons, date("d", $date), date("m", $date), date("Y", $date))) {
                    // Recherche une leçon à cette heure
                    if ($liste_lecon_bdd->lecon_existe_a_heure($liste_lecons, $heure)) {
                        $affiche_leçon_code = '';
                        $leçon_code = true;
                    } else {
                        $leçon_code = false;
                    }
                } else {
                    $leçon_code = false;
                }
                $leçon_conduite = false;
                ?>
                <td class="<?php echo $class; ?>">
                    <ul id="menu-demo2">
                        <li>
                            <p class="<?php echo $class; ?>">
                                <?php
                                if ($leçon_code) {
                                    echo '<p>Leçon de code ' . $heure . 'h </p>';
                                } else {
                                    echo '<p>_</p>';
                                }
                                if ($leçon_conduite) {
                                    echo '<p>Leçon de conduite ' . $heure . 'h </p>';
                                } else {
                                    echo '<p>_</p>';
                                }
                                ?>
                            </p>
                            <ul>
                                <?php if (!$leçon_code) { ?>
                                    <li>
                                        <a href="#" onClick="AjouteLeconCode(<?php echo $date . ', ' . $heure; ?>);">Ajouter leçon de code</a>
                                    </li>
                                <?php } else { ?>
                                    <li>
                                        <a href="#" onClick="EnleverLeconCode(<?php echo $date . ', ' . $heure; ?>);">Enlever leçon de code</a>
                                    </li>
                                    <?php
                                    $leçon_code = false;
                                }

                                if (!$leçon_conduite) { ?>
                                    <li>
                                        <a href="<?php echo $site_url; ?>pages/lecons_conduite/ajouter.php">Leçon de conduite</a>
                                    </li>
                                <?php } else { ?>
                                    <li>
                                        <a href="<?php echo $site_url; ?>pages/lecons_conduite/modifier.php">Leçon de conduite</a>
                                    </li>
                                    <li>
                                        <a href="#" onClick="EnleverLeconConduite(<?php echo $date . ', ' . $heure; ?>);">Enlever leçon de
                                            conduite
                                        </a>
                                    </li>
                                    <?php
                                    $leçon_conduite = false;
                                }
                                ?>

                            </ul>
                        </li>
                    </ul>
                </td>
                <?php
            }

            echo '</tr>';
        }
        ?>

    </table>
