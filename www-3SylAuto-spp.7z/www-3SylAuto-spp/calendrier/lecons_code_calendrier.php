<html>
	<head>
		<style>
			caption 
			{
			   margin: auto; 
			   font-family: Arial, Times, "Times New Roman", serif;
			   font-weight: bold;
			   font-size: 1.2em;
			   color: #EFF3FF;
			   margin-bottom: 20px; 
			   
			}

			table 
			{
			   margin: auto; 
			   border: 4px outset #EFF3FF; 
			   border-collapse: collapse; 
			   width: 100%;
			}

			th
			{
			   background-color: #EFF3FF;
			   color: black;
			   font-size: 1em;
			   font-family: Arial, "Arial Black", Times, "Times New Roman", serif;
			   border: 1px;
			   text-align: center;
			}
			
			.heure 
			{
				background-color: #EFF3FF;
				color: black;
				font-size: 1em;
				font-family: Arial, "Arial Black", Times, "Times New Roman", serif;
				text-align: center;
				width: 2%;
			}

			td 
			{
			   border: 1px solid black;
			   font-family: "Trebuchet MS", "Times", serif;
			   font-size: 1em;
			   text-align: center; 
			   padding: 5px; 
			   width: 14%;
			   height: 35px;			   
			}
			
			.courant
			{
				background-color: #87E990;
			}
			
			.hautgauche 
			{
				border: 1px solid black;
				background-color: #FFFFFF;
				width: 2%;
			}
			
			
			
			jourcourant 
			{
				background-color: #87E990;
				text-decoration: underline;
				font-weight: bold;
				font-size: 1.3em;
			}
			
			texte 
			{
				display:block;
				background-color: #CDF0F0;
				font-size: 1.3em;
			}
			
			</style>
			</head>
			<body>
			<td class="machin">
			<?php
				include_once($site_racine.'bdd/lecons_bdd.php');
				/* A FAIRE --> Test si l'utilisateur connecté est un élève */
				$liste_lecon_bdd = new Liste_Lecon();
				
				$liste_lecons = $liste_lecon_bdd->liste_lecons_code();
			?>
			
			
			<?php
				// Définit le fuseau horaire par défaut à utiliser. Disponible depuis PHP 5.1
				date_default_timezone_set('UTC');			
				$jour = array("Lundi","Mardi","Mercredi","Jeudi","Vendredi","Samedi","Dimanche"); 
				$mois = array("","Janvier","Février","Mars","Avril","Mai","Juin","Juillet","Août","Septembre","Octobre","Novembre","Décembre"); 

				$week = date("W");
				$year = (isset($_GET['year']))?$_GET['year']:date("Y");
				$week = (isset($_GET['week']))?$_GET['week']:Date('W');
				if($week>53){
					$year+= 1;
					$week=1;
				} else if($week<1){
					$year-= 1;
					$week=53;
				}
				
			?>
			<table>
				<caption>
					<?php echo '<a href="'.$_SERVER["PHP_SELF"].'?week='.($week-1).'&year='.$year.'"><<</a>'; // Previous week
					// Affichage de la semaine
					echo '<span style="color: #000000;"> Semaine '.$week.' </span>';
					
					echo '<a href="'.$_SERVER["PHP_SELF"].'?week='.($week+1).'&year='.$year.'">>></a>'; // Next week
					?>
				</caption>

			
				<tr>
				<th class="hautgauche"></th>
					<?php
					for($day=1; $day<=7; $day++)
					{
						$d = strtotime($year."W".$week.$day);
						if (date("m",$d) == date('m') && date("Y",$d) == date('Y') && date("d",$d) == date("d")) {
							echo '<th><jourcourant>'.$jour[$day-1].' '.date("d",$d).' '.$mois[date("n",$d)].'</jourcourant></th>';
						} else {
							echo '<th>'.$jour[$day-1].' '.date("d",$d).' '.$mois[date("n",$d)].'</th>';
						}
							
					}
					?>
				</tr>

			<?php
				for ($heure = $_SESSION["heure_ouverture"]; $heure <= $_SESSION["heure_fermeture"]; $heure++) {
					echo '<tr>'; // Nouvelle ligne du tableau
					echo '<td class="heure">'.$heure.':00'.'</td>';

					for($day=1; $day<=7; $day++) {
						$d = strtotime($year."W".$week.$day);
						if (date("m",$d) == date("m") && date("Y",$d) == date("Y") && date("d",$d) == date("d")) {
							// Recherche une leçon à cette date
							if ($liste_lecon_bdd->lecon_existe_a_date($liste_lecons, date("d",$d), date("m",$d), date("Y",$d))) {
								// Recherche une leçon à cette heure
								if ($liste_lecon_bdd->lecon_existe_a_heure($liste_lecons, $heure)) {
									echo '<td class="courant"><texte>Leçon de code</texte></td>';
								} else {
									echo '<td class="courant"></td>';
								}
								
							} else {
								echo '<td class="courant"></td>';
							}	
						} else {
							// Recherche une leçon à cette date
							if ($liste_lecon_bdd->lecon_existe_a_date($liste_lecons, date("d",$d), date("m",$d), date("Y",$d))) {
								// Recherche une leçon à cette heure
								if ($liste_lecon_bdd->lecon_existe_a_heure($liste_lecons, $heure)) {
									echo '<td><texte>Leçon de code</texte></td>';
								} else {
									echo '<td></td>';
								}
							} else {
								echo '<td></td>';
							}		
						}
					}
						
					echo '</tr>';
				}
			?>

		</table>
	</body>
</html>