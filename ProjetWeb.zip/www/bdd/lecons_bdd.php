<?php
	/**
	 * Cette fonction permet de récupérer les leçons d'un élève
	 */
	function liste_lecons_eleve($param_eleveNum) {
		
		/* Connexion à MySQL */
		$cnx = mysql_connect("localhost","root","root");			
		/* Erreur si connexion échouée */
		if(!$cnx){
			echo 'Impossible de se connecter : ' . mysql_error($cnx);
		}
		/* Choix de la BD */
		mysql_select_db("ae");
		
		/* Requête pour récupérer les albums */
		$requete1 = "SELECT leconDate, leconHeure, moniNum FROM lecon_conduite WHERE eleveNum = ".$param_eleveNum;
		$resultat1 = mysql_query($requete1);
		$nb_lecons = 0;
		
		
		/* Curseur pour récupérer chaque album et les mettre dans un tableau */
		while($ligne_courante=mysql_fetch_object($resultat1)) {
			// Mise des informations de la leçon courante dans un tableau
			$lecon_courante = array(
				"leconDate" => $ligne_courante->leconDate, 
				"leconHeure" => $ligne_courante->leconHeure, 
				"moniNum" => $ligne_courante->moniNum
			);
			$liste_lecons[$nb_lecons] = $lecon_courante;
			$nb_lecons++;
		}	
		if (isset($liste_lecons)) {
			return $liste_lecons; // on renvoie le tableau
		} else {
			echo '<br/>Aucune leçon trouvée<br/>';
		}
		mysql_close(); // déconnexion de MySQL
	}
	
	/**
	 * Cette fonction permet de savoir si une leçon d'une liste existe à une date
	 */
	function lecon_existe_a_date($param_liste_lecons, $param_jour, $param_mois, $param_an) {
		$i = 0;
		for ($i; $i<count($param_liste_lecons); $i++) {
			$lecon_courante = $param_liste_lecons[$i];
			if ($lecon_courante["leconDate"] == $param_an."-".$param_mois."-".$param_jour) {
				return true;
			}
		}
	}
?>