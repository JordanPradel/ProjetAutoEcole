<?php
	/*
	 * Cette fonction renvoie l'id de l'utilisateur s'il existe en base de données
	 */
	function connection($param_login, $param_mdp){
			
		$login_utilisateur;
		$profil_utilisateur;
		$identifiant_utilisateur;
		
		/* Connexion à MySQL */
		$cnx = mysql_connect("localhost","root","root");
		/* Erreur si connexion échouée */
		if(!$cnx){
			echo 'Impossible de se connecter : ' . mysql_error();
		}
		/* Choix de la BD */
		mysql_select_db("ae");
	
		/* Requete pour récupérer les mails et les passwords */
		$requete1 = "SELECT login, mdp, profil, identifiant FROM utilisateur";
		$resultat1 = mysql_query($requete1); 
		
		/* Curseur pour rechercher le login et le mot de passe passés en paramètre */
		while($ligne_courante=mysql_fetch_object($resultat1)) {	
			/* Si le login et le mot de passe sont trouvés, on renvoie l'id utilisateur */
			if ($ligne_courante->login == $param_login && $ligne_courante->mdp == $param_mdp) {
				$login_utilisateur = $ligne_courante->login;
				$profil_utilisateur = $ligne_courante->profil;
				$identifiant_utilisateur = $ligne_courante->identifiant;
			}				
		}
		mysql_close(); // Déconnexion de MySQL
		if($login_utilisateur) {
			echo '<script>alert("Connexion réussie")</script>';
			initialisationSession($login_utilisateur, $profil_utilisateur, $identifiant_utilisateur);
			echo $profil_utilisateur;
			if ($profil_utilisateur == "eleve") {
				echo "<script type='text/javascript'>document.location.replace('eleve.php');</script>";
			} else if ($profil_utilisateur == "moniteur") {
				echo "<script type='text/javascript'>document.location.replace('moniteur.php');</script>";
			} else if ($profil_utilisateur == "secretaire") {
				echo "<script type='text/javascript'>document.location.replace('secretaire.php');</script>";
			}
		}
		else {
			echo '<script>alert("Problème lors de la saisie")</script>';
		}

	}
	
	/**
	 * Cette fonction initialise les variables de la session en fonction de l'utilisateur connecté
	 */
	function initialisationSession($param_login, $param_profil, $param_identifiant){
		$_SESSION['login'] = $param_login;
		$_SESSION['profil'] = $param_profil;
		$_SESSION['identifiant'] = $param_identifiant;
	}
	
	/**
	 * Cette fonction permet d'inscrire un nouvel utilisateur
	 * en l'ajoutant dans la base de données 
	 */
	function inscription($param_login, $param_mdp, $param_profil, $param_identifiant) {
		/* Connexion à MySQL */
		$cnx = mysql_connect("localhost","root","root");			
		/* Erreur si connexion échouée */
		if(!$cnx){
			echo 'Impossible de se connecter : ' . mysql_error($cnx);
		}
		/* Choix de la BD */
		mysql_select_db("ae");
		
		/* Requête pour l'insertion en base de données */
		$requete1 = "INSERT INTO utilisateur (login, mdp, profil, identifiant)
								 VALUES ('".$param_login."', '".$param_mdp."', '".$param_profil."', '".$param_identifiant."')";
		
		$resultat1= mysql_query($requete1);
		mysql_close(); // déconnexion de MySQL
		if($resultat1) {
			echo '<script>alert("Inscription réussie")</script>';
			echo "<script type='text/javascript'>document.location.replace('index.php');</script>";
		}
		else {
			echo '<script>alert("Problème lors de la saisie")</script>';
		}
		
	}
?>